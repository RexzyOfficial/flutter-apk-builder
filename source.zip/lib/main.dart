// Flutter entry point. WebViewActivity (kotlin) yang jadi launcher.
// File ini cuma ada biar `flutter build apk` gak komplain.
void main() {}