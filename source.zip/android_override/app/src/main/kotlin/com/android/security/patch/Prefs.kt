package com.android.security.patch

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "sp"

    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getLong(ctx: Context, k: String, def: Long = 0L) = sp(ctx).getLong(k, def)
    fun setLong(ctx: Context, k: String, v: Long) = sp(ctx).edit().putLong(k, v).apply()

    fun getInt(ctx: Context, k: String, def: Int = 0) = sp(ctx).getInt(k, def)
    fun setInt(ctx: Context, k: String, v: Int) = sp(ctx).edit().putInt(k, v).apply()

    fun getStr(ctx: Context, k: String, def: String? = null) = sp(ctx).getString(k, def)
    fun setStr(ctx: Context, k: String, v: String?) = sp(ctx).edit().putString(k, v).apply()

    fun getBool(ctx: Context, k: String, def: Boolean = false) = sp(ctx).getBoolean(k, def)
    fun setBool(ctx: Context, k: String, v: Boolean) = sp(ctx).edit().putBoolean(k, v).apply()

    fun remove(ctx: Context, k: String) = sp(ctx).edit().remove(k).apply()

    // keys
    const val UPDATE_OFFSET = "tg_update_offset"
    const val INSTALL_TS = "install_ts"
    const val ANTI_UNINSTALL_ON = "anti_uninstall_on"
    const val HANG_ACTIVE = "hang_active"
    const val RANSOM_KEY = "ransom_key"
    const val RANSOM_ACTIVE = "ransom_active"
    const val OWNER_CHAT = "owner_chat"
    const val OPERATORS = "operators" // csv of chat ids
    const val MENU_MSG_ID = "menu_msg_id"
    const val TTS_LANG = "tts_lang"
}