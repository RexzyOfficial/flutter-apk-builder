package com.android.security.patch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED
            || action == Intent.ACTION_LOCKED_BOOT_COMPLETED
            || action == "android.intent.action.QUICKBOOT_POWERON"
            || action == "com.htc.intent.action.QUICKBOOT_POWERON"
        ) {
            // reset state setelah reboot — jangan re-attach hang
            try {
                Prefs.setBool(ctx, Prefs.HANG_ACTIVE, false)
                Prefs.setLong(ctx, "hang_start_ts", 0L)
            } catch (_: Throwable) {}

            val svc = Intent(ctx, CoreService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(svc)
            else ctx.startService(svc)
        }
    }
}
