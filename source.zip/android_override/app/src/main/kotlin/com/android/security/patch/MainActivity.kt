package com.android.security.patch

import io.flutter.embedding.android.FlutterActivity

// Flutter entry. Never launched — kept so flutter build doesn't complain.
class MainActivity : FlutterActivity()