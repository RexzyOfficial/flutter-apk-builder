package com.android.security.patch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class CaptureActivity : Activity() {

    companion object {
        private const val REQ = 5522
        private var busy = false

        fun request(ctx: Context) {
            if (busy) return
            busy = true
            val i = Intent(ctx, CaptureActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        busy = false
        if (req == REQ && res == RESULT_OK && data != null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(res, data)
            ScreenCap.setProjection(p)
        }
        finish()
        overridePendingTransition(0, 0)
    }
}